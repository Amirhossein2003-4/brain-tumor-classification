"""
train.py - one self-contained training script for the brain-tumor leakage audit.

    python train.py                                  # defaults below
    python train.py mode=slice fold=0
    python train.py mode=patient fold=all            # runs folds 0..4 one after another
    python train.py mode=authors fold=2 freeze_below_stride=8 tag=fb8
    python train.py cut_blocks=9 hidden=64 epochs=40 augment=True

Any key of CFG can be overridden as key=value on the command line (values are parsed as Python
literals: 8, 1e-3, True, None, "x").  Every run gets its OWN folder under run_root, so nothing is
ever overwritten (even identical configs).  Inside a run folder:

    config.json         full config + split info (sizes, patients, leakage counts)
    log.txt             everything printed to the console
    epochs.csv          one line per epoch (train/val metrics, lr, time)
    grad_report.csv     per-block gradient stats at epoch 1 and every grad_report_every epochs
    best.pth            FULL checkpoint of the best epoch (model+optimizer+scheduler+cfg+metrics)
    last.pth            full checkpoint of the final epoch
    predictions_best.csv / predictions_last.csv   per-slice test predictions
    metrics.json        all test metrics (best-by-val checkpoint and last epoch)
    curves.png, confusion.png, roc.png, pr.png, calibration.png, per_class.png,
    misclassified.png, grad_norms.png
and one extra line per run is appended to run_root/runs_summary.csv for easy comparison.
"""
import ast
import csv
import json
import math
import os
import random
import sys
import time
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torchvision.models import MobileNet_V3_Small_Weights, mobilenet_v3_small

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from sklearn import metrics as skm  # noqa: E402

from data import BrainTumorDataset, build_cache, make_input  # noqa: E402
from prep_data import SRC as RAW_SRC, read_cvind  # noqa: E402
from splits import ROOT as DATA_ROOT, load_meta, make_folds, train_val_split  # noqa: E402

CLASS_NAMES = ["meningioma", "glioma", "pituitary"]

# =============================================================================
#                                   CONFIG
# =============================================================================
CFG = dict(
    # ---- data / split ------------------------------------------------------
    mode="patient",            # "slice" (random, leaks) | "patient" (grouped) | "authors" (cvind.mat)
    fold=0,                    # 0..4, or "all"
    n_splits=5,
    seed=0,                    # seeds the split (slice/patient modes) AND the training
    size=160,                  # which cache to use (160 or 224 were built)
    data_root=str(DATA_ROOT),
    cvind_path=str(RAW_SRC / "cvind.mat"),
    input_mode="full",         # full | tumor_only | context_only | mask_only  (what the model is allowed to see)
    fill="blur",               # context_only: how the removed tumor region is filled (blur | mean | zero)
    region_margin=0,           # dilate the tumor mask by N pixels (at cache size) before use
    # input_mode="band": distance band around the tumor boundary (see data.make_input)
    band_in=0,                 # inner distance of the ring
    band_out=15,               # outer distance of the ring
    band_unit="px512",         # px512 = pixels of the original 512 grid | rel = multiples of the tumor equivalent radius
    band_tumor=False,          # include the tumor interior in the region of interest
    band_op="keep",            # keep = keep only (tumor +) ring | remove = suppress (tumor +) ring
    band_shuffle=False,        # permute pixel values inside the ring (structure control)
    # ---- model -------------------------------------------------------------
    pretrained=True,
    pretrained_path=r"C:\Users\amir\DL\models\mobilenet_v3_small\mobilenet_v3_small.pth",
    cut_blocks=None,           # None = all 13 feature blocks; e.g. 9 keeps blocks 0..8 only
    hidden=0,                  # 0 = global-avg-pool -> Linear(classes); >0 adds Linear(hidden)+act+dropout
    dropout=0.2,
    # ---- freezing ----------------------------------------------------------
    freeze_below_stride=16,    # blocks whose OUTPUT stride is < this are frozen (s2,s4,s8 frozen; s16,s32 trained)
                               # 0 = freeze nothing, 10**9 = freeze whole backbone (linear probe)
    bn_adapt=True,             # True: BN of frozen blocks stays in train mode (running mean/var adapt to MRI)
    bn_momentum=0.1,           # torchvision's MobileNetV3 uses 0.01 (very slow: ~100-step memory, eval stats lag
                               # behind); 0.1 is the usual PyTorch default. None = keep torchvision's 0.01
    # ---- optimization (AdamW + OneCycle) -------------------------------------
    epochs=30,
    batch_size=32,
    lr_backbone=5e-4,          # OneCycle PEAK lr for the trainable backbone blocks
    lr_head=2e-3,              # OneCycle PEAK lr for the new head
    weight_decay=1e-2,         # AdamW decoupled weight decay (not applied to biases / BN params)
    pct_start=0.2,
    div_factor=25.0,           # start lr = peak / div_factor
    final_div_factor=1e3,      # end lr = start lr / final_div_factor
    grad_clip=0.0,             # 0 = off (gradient report is measured BEFORE clipping)
    class_weights="balanced",  # "balanced" | None
    label_smoothing=0.0,
    # ---- augmentation (train only, applied on the batch) --------------------
    augment=False,
    aug_hflip=True,
    aug_rot=10.0,              # degrees, uniform in +-
    aug_shift=0.05,            # fraction of image size
    aug_scale=0.10,            # zoom in [1-s, 1+s]
    aug_contrast=0.15,
    aug_brightness=0.10,       # in normalized units
    # ---- monitoring --------------------------------------------------------
    monitor="val_macro_f1",    # val_macro_f1 | val_bal_acc | val_acc | val_auc | val_loss (lower is better)
    grad_report_every=5,       # + always at epoch 1
    dead_thresh=1e-7,          # mean grad-norm below this => flagged DEAD
    # ---- misc ----------------------------------------------------------------
    tag="",
    run_root=r"C:\Users\amir\DL\runs\brain_tumor",
    num_threads=None,          # e.g. 8 to limit CPU threads
    num_workers=0,             # keep 0 on Windows (data is already in RAM)
)
# =============================================================================


class Tee:
    """Mirror everything printed to the console into log.txt."""

    def __init__(self, path):
        self.f = open(path, "a", encoding="utf-8")
        self.o = sys.stdout

    def write(self, s):
        self.o.write(s)
        self.f.write(s)

    def flush(self):
        self.o.flush()
        self.f.flush()

    def close(self):
        self.f.close()


def set_seed(s):
    random.seed(s)
    np.random.seed(s)
    torch.manual_seed(s)


# ----------------------------------------------------------------------------
#                                    model
# ----------------------------------------------------------------------------
def load_pretrained_mobilenet(cfg):
    m = mobilenet_v3_small(weights=None)
    p = Path(cfg["pretrained_path"])
    loaded = False
    if p.exists():
        try:
            sd = torch.load(p, map_location="cpu", weights_only=False)   # your own file
            if isinstance(sd, nn.Module):
                sd = sd.state_dict()
            if isinstance(sd, dict) and "state_dict" in sd:
                sd = sd["state_dict"]
            missing, unexpected = m.load_state_dict(sd, strict=False)
            bad = [k for k in missing if k.startswith("features.")]
            if bad:
                raise RuntimeError(f"{len(bad)} backbone keys missing, e.g. {bad[:3]}")
            print(f"loaded pretrained weights from {p} (missing non-backbone keys: {len(missing)}, "
                  f"unexpected: {len(unexpected)})")
            loaded = True
        except Exception as e:  # noqa: BLE001
            print(f"WARNING: could not load {p}: {e}")
    if not loaded:
        print("falling back to torchvision ImageNet weights (needs internet the first time)")
        m = mobilenet_v3_small(weights=MobileNet_V3_Small_Weights.DEFAULT)
    return m


class Net(nn.Module):
    def __init__(self, cfg, n_classes=3):
        super().__init__()
        base = load_pretrained_mobilenet(cfg) if cfg["pretrained"] else mobilenet_v3_small(weights=None)
        blocks = list(base.features.children())
        if cfg["cut_blocks"]:
            blocks = blocks[: int(cfg["cut_blocks"])]
        self.backbone = nn.ModuleList(blocks)

        # measure output stride / channels of every block with a dummy input
        size = int(cfg["size"])
        strides, chans = [], []
        with torch.no_grad():
            x = torch.zeros(1, 3, size, size)
            for b in self.backbone:
                b.eval()
                x = b(x)
                strides.append(int(round(size / x.shape[-1])))
                chans.append(int(x.shape[1]))
        self.strides, self.chans = strides, chans

        layers = [("pool", nn.AdaptiveAvgPool2d(1)), ("flat", nn.Flatten())]
        c = chans[-1]
        if cfg["hidden"] and cfg["hidden"] > 0:
            layers += [("drop0", nn.Dropout(cfg["dropout"])), ("fc1", nn.Linear(c, cfg["hidden"])),
                       ("act", nn.Hardswish()), ("drop1", nn.Dropout(cfg["dropout"])),
                       ("out", nn.Linear(cfg["hidden"], n_classes))]
        else:
            layers += [("drop0", nn.Dropout(cfg["dropout"])), ("out", nn.Linear(c, n_classes))]
        self.head = nn.Sequential(*[m for _, m in layers])
        # keep readable names for the gradient report
        self.head_names = [n for n, _ in layers]

        if cfg["bn_momentum"] is not None:
            for m in self.modules():
                if isinstance(m, nn.BatchNorm2d):
                    m.momentum = float(cfg["bn_momentum"])

        # freezing (always a prefix, because strides never decrease)
        thr = cfg["freeze_below_stride"]
        n_frozen = 0
        for s in strides:
            if s < thr:
                n_frozen += 1
            else:
                break
        self.n_frozen = n_frozen
        for i, b in enumerate(self.backbone):
            for p in b.parameters():
                p.requires_grad = i >= n_frozen

    def forward(self, x):
        for i, b in enumerate(self.backbone):
            if i < self.n_frozen:
                with torch.no_grad():       # frozen prefix: no graph needed (BN stats still update in train mode)
                    x = b(x)
            else:
                x = b(x)
        return self.head(x)

    def set_mode(self, train, bn_adapt):
        self.train(train)
        if train and not bn_adapt:
            for b in self.backbone[: self.n_frozen]:
                for m in b.modules():
                    if isinstance(m, nn.BatchNorm2d):
                        m.eval()

    def unit_of(self, pname):
        """'backbone.4.block.0.0.weight' -> 'backbone.4' ; 'head.1.weight' -> 'head.<layer name>'."""
        parts = pname.split(".")
        if parts[0] == "head":
            return f"head.{self.head_names[int(parts[1])]}"
        return f"backbone.{int(parts[1]):02d}"

    def describe(self):
        print(f"backbone blocks: {len(self.backbone)} | frozen prefix: {self.n_frozen} blocks")
        for i, (s, c) in enumerate(zip(self.strides, self.chans)):
            tag = "FROZEN " if i < self.n_frozen else "trained"
            print(f"  block {i:02d}  out stride {s:>2}  channels {c:>4}  [{tag}]")
        tot = sum(p.numel() for p in self.parameters())
        trn = sum(p.numel() for p in self.parameters() if p.requires_grad)
        print(f"params total {tot:,} | trainable {trn:,}")
        return tot, trn


def make_optimizer(model, cfg):
    groups, max_lrs = [], []
    for part, lr in (("backbone", cfg["lr_backbone"]), ("head", cfg["lr_head"])):
        decay, no_decay = [], []
        for n, p in model.named_parameters():
            if not p.requires_grad or not n.startswith(part):
                continue
            (no_decay if p.ndim <= 1 else decay).append(p)
        if decay:
            groups.append(dict(params=decay, weight_decay=cfg["weight_decay"]))
            max_lrs.append(lr)
        if no_decay:
            groups.append(dict(params=no_decay, weight_decay=0.0))
            max_lrs.append(lr)
    return torch.optim.AdamW(groups, lr=1e-3), max_lrs


# ----------------------------------------------------------------------------
#                               augmentation (batch)
# ----------------------------------------------------------------------------
def augment_batch(x, cfg):
    B = x.shape[0]
    dev = x.device
    if cfg["aug_hflip"]:
        flip = torch.rand(B, device=dev) < 0.5
        x = torch.where(flip[:, None, None, None], x.flip(-1), x)
    ang = (torch.rand(B, device=dev) * 2 - 1) * math.radians(cfg["aug_rot"])
    sc = 1.0 + (torch.rand(B, device=dev) * 2 - 1) * cfg["aug_scale"]
    tx = (torch.rand(B, device=dev) * 2 - 1) * cfg["aug_shift"] * 2
    ty = (torch.rand(B, device=dev) * 2 - 1) * cfg["aug_shift"] * 2
    cos, sin = torch.cos(ang) / sc, torch.sin(ang) / sc
    theta = torch.stack([torch.stack([cos, -sin, tx], 1), torch.stack([sin, cos, ty], 1)], 1)  # (B,2,3)
    grid = F.affine_grid(theta, x.shape, align_corners=False)      # square images -> no aspect-ratio issue
    x = F.grid_sample(x, grid, mode="bilinear", padding_mode="border", align_corners=False)
    c = 1.0 + (torch.rand(B, 1, 1, 1, device=dev) * 2 - 1) * cfg["aug_contrast"]
    b = (torch.rand(B, 1, 1, 1, device=dev) * 2 - 1) * cfg["aug_brightness"]
    return x * c + b


# ----------------------------------------------------------------------------
#                               gradient statistics
# ----------------------------------------------------------------------------
class GradStats:
    """Accumulates per-block gradient norms over all steps of an epoch (measured before clipping)."""

    def __init__(self, model):
        self.units = {}
        for n, p in model.named_parameters():
            self.units.setdefault(model.unit_of(n), []).append(p)
        self.reset()

    def reset(self):
        self.norms = {u: [] for u in self.units}
        self.zero = {u: [] for u in self.units}

    def update(self):
        for u, ps in self.units.items():
            gs = [p.grad for p in ps if p.grad is not None]
            if not gs:
                continue
            sq = sum(float(g.pow(2).sum()) for g in gs)
            n = sum(g.numel() for g in gs)
            z = sum(int((g == 0).sum()) for g in gs)
            self.norms[u].append(math.sqrt(sq))
            self.zero[u].append(z / max(n, 1))

    def report(self, epoch, dead_thresh):
        rows = []
        for u, ps in self.units.items():
            trainable = any(p.requires_grad for p in ps)
            n_params = sum(p.numel() for p in ps)
            pnorm = math.sqrt(sum(float(p.detach().pow(2).sum()) for p in ps))
            if not trainable:
                rows.append(dict(epoch=epoch, unit=u, trainable=0, n_params=n_params, grad_norm_mean=0.0,
                                 grad_norm_max=0.0, zero_frac=0.0, param_norm=pnorm, grad_over_param=0.0,
                                 flag="frozen"))
                continue
            g = self.norms[u]
            gm = float(np.mean(g)) if g else 0.0
            rows.append(dict(epoch=epoch, unit=u, trainable=1, n_params=n_params, grad_norm_mean=gm,
                             grad_norm_max=float(np.max(g)) if g else 0.0,
                             zero_frac=float(np.mean(self.zero[u])) if g else 1.0, param_norm=pnorm,
                             grad_over_param=gm / (pnorm + 1e-12), flag=""))
        live = [r["grad_norm_mean"] for r in rows if r["trainable"] and r["grad_norm_mean"] > dead_thresh]
        med = float(np.median(live)) if live else 0.0
        for r in rows:
            if r["trainable"]:
                if r["grad_norm_mean"] <= dead_thresh:
                    r["flag"] = "DEAD"
                elif med > 0 and r["grad_norm_mean"] < 1e-2 * med:
                    r["flag"] = "weak(<1% of median)"
                elif med > 0 and r["grad_norm_mean"] > 1e2 * med:
                    r["flag"] = "huge(>100x median)"
                else:
                    r["flag"] = "ok"
        return rows


def print_grad_rows(rows):
    print(f"  gradient report (epoch {rows[0]['epoch']}):  unit | mean |g| | max |g| | zero% | |g|/|w| | flag")
    for r in rows:
        if not r["trainable"]:
            continue
        print(f"    {r['unit']:<14} {r['grad_norm_mean']:.3e}  {r['grad_norm_max']:.3e}  "
              f"{100 * r['zero_frac']:5.1f}%  {r['grad_over_param']:.2e}  {r['flag']}")
    n_frozen = sum(1 for r in rows if not r["trainable"])
    bad = [r["unit"] for r in rows if r["flag"] in ("DEAD",)]
    print(f"    ({n_frozen} frozen units not listed) DEAD units: {bad if bad else 'none'}")


# ----------------------------------------------------------------------------
#                                    metrics
# ----------------------------------------------------------------------------
def ece_score(prob, y, bins=10):
    conf, pred = prob.max(1), prob.argmax(1)
    acc = (pred == y).astype(float)
    edges = np.linspace(0, 1, bins + 1)
    e = 0.0
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (conf > lo) & (conf <= hi)
        if m.any():
            e += m.mean() * abs(acc[m].mean() - conf[m].mean())
    return float(e)


def compute_metrics(y, prob, pid=None):
    pred = prob.argmax(1)
    k = prob.shape[1]
    labels = list(range(k))
    out = dict(
        n=int(len(y)),
        acc=float(skm.accuracy_score(y, pred)),
        bal_acc=float(skm.balanced_accuracy_score(y, pred)),
        macro_f1=float(skm.f1_score(y, pred, average="macro", labels=labels, zero_division=0)),
        weighted_f1=float(skm.f1_score(y, pred, average="weighted", labels=labels, zero_division=0)),
        mcc=float(skm.matthews_corrcoef(y, pred)),
        kappa=float(skm.cohen_kappa_score(y, pred)),
        log_loss=float(-np.mean(np.log(np.clip(prob[np.arange(len(y)), y], 1e-7, 1.0)))),
        brier=float(np.mean(np.sum((prob - np.eye(k)[y]) ** 2, axis=1))),
        ece=ece_score(prob, y),
    )
    onehot = np.eye(k)[y]
    try:
        out["auc_macro_ovr"] = float(skm.roc_auc_score(onehot, prob, average="macro"))
        out["auc_per_class"] = [float(skm.roc_auc_score(onehot[:, c], prob[:, c])) for c in labels]
        out["ap_per_class"] = [float(skm.average_precision_score(onehot[:, c], prob[:, c])) for c in labels]
        out["ap_macro"] = float(np.mean(out["ap_per_class"]))
    except ValueError:
        out["auc_macro_ovr"] = float("nan")
    p, r, f, s = skm.precision_recall_fscore_support(y, pred, labels=labels, zero_division=0)
    out["per_class"] = {CLASS_NAMES[c]: dict(precision=float(p[c]), recall=float(r[c]), f1=float(f[c]),
                                             support=int(s[c])) for c in labels}
    out["confusion"] = skm.confusion_matrix(y, pred, labels=labels).tolist()
    if pid is not None:   # patient-level: mean softmax over the slices of each test patient
        up = np.unique(pid)
        pp = np.stack([prob[pid == u].mean(0) for u in up])
        yp = np.array([y[pid == u][0] for u in up])
        pr = pp.argmax(1)
        out["patient_level"] = dict(
            n_patients=int(len(up)), acc=float(skm.accuracy_score(yp, pr)),
            bal_acc=float(skm.balanced_accuracy_score(yp, pr)),
            macro_f1=float(skm.f1_score(yp, pr, average="macro", labels=labels, zero_division=0)))
    return out


@torch.no_grad()
def predict(model, loader, device):
    model.set_mode(False, True)
    logits, ys = [], []
    for x, y in loader:
        logits.append(model(x.to(device)).cpu())
        ys.append(y)
    logits, ys = torch.cat(logits), torch.cat(ys)
    loss = float(F.cross_entropy(logits, ys))
    return torch.softmax(logits, 1).numpy(), ys.numpy(), loss


# ----------------------------------------------------------------------------
#                                     plots
# ----------------------------------------------------------------------------
def plot_curves(ep, lr_steps, path):
    e = [r["epoch"] for r in ep]
    fig, ax = plt.subplots(2, 3, figsize=(16, 8))
    ax[0, 0].plot(e, [r["train_loss"] for r in ep], label="train")
    ax[0, 0].plot(e, [r["val_loss"] for r in ep], label="val")
    ax[0, 0].set_title("loss"); ax[0, 0].legend()
    ax[0, 1].plot(e, [r["train_acc"] for r in ep], label="train acc")
    ax[0, 1].plot(e, [r["val_acc"] for r in ep], label="val acc")
    ax[0, 1].set_title("accuracy"); ax[0, 1].legend()
    ax[0, 2].plot(e, [r["val_bal_acc"] for r in ep], label="val balanced acc")
    ax[0, 2].plot(e, [r["val_macro_f1"] for r in ep], label="val macro F1")
    ax[0, 2].set_title("val class-balanced metrics"); ax[0, 2].legend()
    ax[1, 0].plot(e, [r["val_auc"] for r in ep]); ax[1, 0].set_title("val macro AUC (OvR)")
    ax[1, 1].plot(e, [r["train_acc"] - r["val_acc"] for r in ep])
    ax[1, 1].axhline(0, color="k", lw=0.5); ax[1, 1].set_title("train acc - val acc (overfitting gap)")
    arr = np.array(lr_steps)
    for g in range(arr.shape[1]):
        ax[1, 2].plot(arr[:, g], lw=0.8)
    ax[1, 2].set_yscale("log"); ax[1, 2].set_title("lr per step (one line per param group)")
    for a in ax.flat:
        a.grid(alpha=0.3)
    for a in list(ax[0]) + list(ax[1, :2]):
        a.set_xlabel("epoch")
    ax[1, 2].set_xlabel("step")
    plt.tight_layout(); plt.savefig(path, dpi=130); plt.close()


def plot_confusion(cm, path, title):
    cm = np.array(cm)
    cmn = cm / np.maximum(cm.sum(1, keepdims=True), 1)
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.5))
    for a, m, t, fmt in ((ax[0], cm, "counts", "d"), (ax[1], cmn, "row-normalized (recall)", ".2f")):
        a.imshow(m, cmap="Blues", vmin=0, vmax=(m.max() if fmt == "d" else 1))
        a.set_xticks(range(3)); a.set_xticklabels(CLASS_NAMES, rotation=20)
        a.set_yticks(range(3)); a.set_yticklabels(CLASS_NAMES)
        a.set_xlabel("predicted"); a.set_ylabel("true"); a.set_title(t)
        for i in range(3):
            for j in range(3):
                a.text(j, i, format(m[i, j], fmt), ha="center", va="center",
                       color="white" if m[i, j] > m.max() / 2 else "black")
    fig.suptitle(title); plt.tight_layout(); plt.savefig(path, dpi=130); plt.close()


def plot_roc_pr(y, prob, roc_path, pr_path):
    onehot = np.eye(prob.shape[1])[y]
    fig, ax = plt.subplots(figsize=(5.5, 5))
    for c in range(3):
        if onehot[:, c].sum() == 0:
            continue
        fpr, tpr, _ = skm.roc_curve(onehot[:, c], prob[:, c])
        ax.plot(fpr, tpr, label=f"{CLASS_NAMES[c]} (AUC {skm.auc(fpr, tpr):.3f})")
    ax.plot([0, 1], [0, 1], "k--", lw=0.6); ax.set_xlabel("FPR"); ax.set_ylabel("TPR")
    ax.set_title("ROC one-vs-rest (test)"); ax.legend(); ax.grid(alpha=0.3)
    plt.tight_layout(); plt.savefig(roc_path, dpi=130); plt.close()
    fig, ax = plt.subplots(figsize=(5.5, 5))
    for c in range(3):
        if onehot[:, c].sum() == 0:
            continue
        p, r, _ = skm.precision_recall_curve(onehot[:, c], prob[:, c])
        ax.plot(r, p, label=f"{CLASS_NAMES[c]} (AP {skm.average_precision_score(onehot[:, c], prob[:, c]):.3f})")
        ax.axhline(onehot[:, c].mean(), color="gray", lw=0.4, ls=":")
    ax.set_xlabel("recall"); ax.set_ylabel("precision"); ax.set_title("precision-recall (test)")
    ax.legend(); ax.grid(alpha=0.3)
    plt.tight_layout(); plt.savefig(pr_path, dpi=130); plt.close()


def plot_calibration(y, prob, path):
    conf, pred = prob.max(1), prob.argmax(1)
    correct = (pred == y).astype(float)
    edges = np.linspace(0, 1, 11)
    xs, accs, cnt = [], [], []
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (conf > lo) & (conf <= hi)
        cnt.append(int(m.sum()))
        if m.any():
            xs.append(conf[m].mean()); accs.append(correct[m].mean())
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.5))
    ax[0].plot([0, 1], [0, 1], "k--", lw=0.6)
    ax[0].plot(xs, accs, "o-")
    ax[0].set_xlabel("mean confidence"); ax[0].set_ylabel("accuracy")
    ax[0].set_title(f"reliability diagram (ECE {ece_score(prob, y):.3f})"); ax[0].grid(alpha=0.3)
    ax[1].hist(conf[correct == 1], bins=20, range=(0, 1), alpha=0.7, label="correct")
    ax[1].hist(conf[correct == 0], bins=20, range=(0, 1), alpha=0.7, label="wrong")
    ax[1].set_xlabel("confidence"); ax[1].set_title("confidence histogram"); ax[1].legend()
    plt.tight_layout(); plt.savefig(path, dpi=130); plt.close()


def plot_per_class(m, path):
    names = CLASS_NAMES
    w = 0.25
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for k, key in enumerate(["precision", "recall", "f1"]):
        v = [m["per_class"][n][key] for n in names]
        ax.bar(np.arange(3) + (k - 1) * w, v, w, label=key)
    ax.set_xticks(range(3))
    ax.set_xticklabels([f"{n}\n(n={m['per_class'][n]['support']})" for n in names])
    ax.set_ylim(0, 1.05); ax.legend(); ax.grid(alpha=0.3, axis="y"); ax.set_title("per-class test metrics")
    plt.tight_layout(); plt.savefig(path, dpi=130); plt.close()


def plot_misclassified(images, rows_idx, y, prob, pid, path, k=12):
    pred = prob.argmax(1)
    wrong = np.where(pred != y)[0]
    if len(wrong) == 0:
        return
    wrong = wrong[np.argsort(-prob[wrong, pred[wrong]])][:k]
    cols = 4
    rws = int(math.ceil(len(wrong) / cols))
    fig, ax = plt.subplots(rws, cols, figsize=(3.2 * cols, 3.4 * rws))
    ax = np.atleast_2d(ax)
    for a in ax.flat:
        a.axis("off")
    for a, w in zip(ax.flat, wrong):
        a.imshow(images[rows_idx[w]].astype(np.float32), cmap="gray", vmin=0, vmax=1)
        a.set_title(f"true {CLASS_NAMES[y[w]][:3]} / pred {CLASS_NAMES[pred[w]][:3]} "
                    f"({prob[w, pred[w]]:.2f})\npid {pid[w]}", fontsize=8)
    fig.suptitle("most confident mistakes (test)"); plt.tight_layout(); plt.savefig(path, dpi=130); plt.close()


def plot_grad_norms(grad_rows, path):
    units = sorted({r["unit"] for r in grad_rows if r["trainable"]})
    epochs = sorted({r["epoch"] for r in grad_rows})
    if not units:
        return
    fig, ax = plt.subplots(1, 2, figsize=(15, 5))
    cmap = plt.get_cmap("viridis")
    for i, u in enumerate(units):
        ys = [next((r["grad_norm_mean"] for r in grad_rows if r["unit"] == u and r["epoch"] == e), np.nan)
              for e in epochs]
        ax[0].plot(epochs, np.maximum(ys, 1e-12), "o-", color=cmap(i / max(len(units) - 1, 1)), label=u)
    ax[0].set_yscale("log"); ax[0].set_xlabel("epoch"); ax[0].set_ylabel("mean grad L2 norm")
    ax[0].set_title("gradient norm per block (trainable only)"); ax[0].legend(fontsize=6, ncol=2); ax[0].grid(alpha=0.3)
    mat = np.array([[next((r["grad_over_param"] for r in grad_rows if r["unit"] == u and r["epoch"] == e), np.nan)
                     for e in epochs] for u in units])
    im = ax[1].imshow(np.log10(np.maximum(mat, 1e-12)), aspect="auto", cmap="magma")
    ax[1].set_yticks(range(len(units))); ax[1].set_yticklabels(units, fontsize=6)
    ax[1].set_xticks(range(len(epochs))); ax[1].set_xticklabels(epochs)
    ax[1].set_xlabel("epoch"); ax[1].set_title("log10(|grad| / |weights|)")
    plt.colorbar(im, ax=ax[1])
    plt.tight_layout(); plt.savefig(path, dpi=130); plt.close()


# ----------------------------------------------------------------------------
#                                  one full run
# ----------------------------------------------------------------------------
def get_fold(meta, cfg):
    """Return (train_idx, val_idx, test_idx, inner_mode) as row indices."""
    mode, k = cfg["mode"], int(cfg["fold"])
    if mode == "authors":
        f = read_cvind(Path(cfg["cvind_path"]))
        assert len(f) == len(meta["idx"]), "cvind length != number of slices"
        folds = [(np.where(f != v)[0], np.where(f == v)[0]) for v in sorted(set(f.tolist()))]
        inner = "patient"          # authors' folds are patient-disjoint -> keep val patient-disjoint too
    else:
        folds = make_folds(meta, mode, cfg["n_splits"], cfg["seed"])
        inner = mode               # validation split must have the SAME leakage property as the test split
    tr, te = folds[k]
    tr2, va = train_val_split(meta, tr, inner, cfg["seed"])
    return tr2, va, te, inner


def split_info(meta, tr, va, te):
    pid, y = meta["pid"], meta["label"]

    def shared(a, b):
        s = set(pid[a]) & set(pid[b])
        return len(s), int(np.isin(pid[b], list(s)).sum()) if s else 0

    info = dict(n_train=int(len(tr)), n_val=int(len(va)), n_test=int(len(te)),
                patients_train=int(len(set(pid[tr]))), patients_val=int(len(set(pid[va]))),
                patients_test=int(len(set(pid[te]))),
                class_counts_train=np.bincount(y[tr], minlength=3).tolist(),
                class_counts_val=np.bincount(y[va], minlength=3).tolist(),
                class_counts_test=np.bincount(y[te], minlength=3).tolist())
    info["shared_patients_train_val"], info["val_slices_with_train_patient"] = shared(tr, va)
    info["shared_patients_train_test"], info["test_slices_with_train_patient"] = shared(tr, te)
    return info


def run_one(cfg):
    run_name = (f"{datetime.now():%Y%m%d_%H%M%S}_{cfg['mode']}_f{cfg['fold']}_s{cfg['seed']}"
                f"_fb{cfg['freeze_below_stride'] if cfg['freeze_below_stride'] < 10**6 else 'ALL'}"
                + (f"_{cfg['input_mode']}" if cfg["input_mode"] not in ("full", "band") else "")
                + (f"_band-{cfg['band_op']}-{cfg['band_in']}-{cfg['band_out']}{'-T' if cfg['band_tumor'] else ''}"
                   f"{'-shuf' if cfg['band_shuffle'] else ''}-{cfg['band_unit']}" if cfg["input_mode"] == "band" else "")
                + (f"_{cfg['tag']}" if cfg["tag"] else ""))
    out = Path(cfg["run_root"]) / run_name
    out.mkdir(parents=True, exist_ok=False)
    tee = Tee(out / "log.txt")
    sys.stdout = tee
    try:
        return _run_one(cfg, out, run_name)
    except Exception:
        import traceback
        traceback.print_exc(file=tee)
        raise
    finally:
        sys.stdout = tee.o
        tee.close()


def _run_one(cfg, out, run_name):
    if cfg["num_threads"]:
        torch.set_num_threads(int(cfg["num_threads"]))
    set_seed(cfg["seed"])
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"=== run {run_name} | device {device} | torch {torch.__version__} ===")
    print(json.dumps(cfg, indent=1))

    meta = load_meta(cfg["data_root"])
    images, masks = build_cache(cfg["data_root"], size=cfg["size"])
    if cfg["input_mode"] != "full":
        n_empty = int((masks.reshape(len(masks), -1).sum(1) == 0).sum())
        band = dict(**{"in": cfg["band_in"], "out": cfg["band_out"]}, unit=cfg["band_unit"], tumor=cfg["band_tumor"],
                    op=cfg["band_op"], shuffle=cfg["band_shuffle"], seed=cfg["seed"]) if cfg["input_mode"] == "band" else None
        images = make_input(images, masks, cfg["input_mode"], cfg["fill"], cfg["region_margin"], band=band)
        print(f"input_mode={cfg['input_mode']} fill={cfg['fill']} margin={cfg['region_margin']} | "
              f"slices with an empty mask: {n_empty} | mean pixel value of the new input: "
              f"{float(images.astype(np.float32).mean()):.3f}")
    tr, va, te, inner = get_fold(meta, cfg)
    info = split_info(meta, tr, va, te)
    print(f"split mode={cfg['mode']} (inner val mode={inner}) fold={cfg['fold']}")
    print(json.dumps(info, indent=1))
    with open(out / "config.json", "w", encoding="utf-8") as f:
        json.dump(dict(cfg=cfg, split=info), f, indent=1)

    labels = meta["label"]
    mk = lambda idx, shuffle: DataLoader(  # noqa: E731
        BrainTumorDataset(images, labels, idx), batch_size=cfg["batch_size"], shuffle=shuffle,
        drop_last=shuffle, num_workers=cfg["num_workers"])
    dl_tr, dl_va, dl_te = mk(tr, True), mk(va, False), mk(te, False)

    model = Net(cfg).to(device)
    n_total, n_train_params = model.describe()
    opt, max_lrs = make_optimizer(model, cfg)
    sched = torch.optim.lr_scheduler.OneCycleLR(
        opt, max_lr=max_lrs, epochs=cfg["epochs"], steps_per_epoch=len(dl_tr), pct_start=cfg["pct_start"],
        div_factor=cfg["div_factor"], final_div_factor=cfg["final_div_factor"])
    if cfg["class_weights"] == "balanced":
        cnt = np.bincount(labels[tr], minlength=3).astype(np.float32)
        w = torch.tensor(cnt.sum() / (3 * cnt), device=device)
    else:
        w = None
    crit = nn.CrossEntropyLoss(weight=w, label_smoothing=cfg["label_smoothing"])
    print(f"class weights: {None if w is None else [round(float(v), 3) for v in w]} | "
          f"steps/epoch {len(dl_tr)}")

    gstats = GradStats(model)
    grad_rows, ep_rows, lr_steps = [], [], []
    mon = cfg["monitor"]
    higher = mon != "val_loss"
    best_val, best_epoch = (-1e9 if higher else 1e9), 0
    ep_csv = out / "epochs.csv"

    for epoch in range(1, cfg["epochs"] + 1):
        t0 = time.time()
        model.set_mode(True, cfg["bn_adapt"])
        collect = epoch == 1 or epoch % cfg["grad_report_every"] == 0
        if collect:
            gstats.reset()
        tl, tc, tn = 0.0, 0, 0
        for x, y in dl_tr:
            x, y = x.to(device), y.to(device)
            if cfg["augment"]:
                x = augment_batch(x, cfg)
            logits = model(x)
            loss = crit(logits, y)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            if collect:
                gstats.update()
            if cfg["grad_clip"] > 0:
                nn.utils.clip_grad_norm_(model.parameters(), cfg["grad_clip"])
            opt.step()
            lr_steps.append([g["lr"] for g in opt.param_groups])
            sched.step()
            tl += float(loss.detach()) * len(y)
            tc += int((logits.argmax(1) == y).sum())
            tn += len(y)
        prob_v, y_v, vloss = predict(model, dl_va, device)
        mv = compute_metrics(y_v, prob_v)
        row = dict(epoch=epoch, train_loss=tl / tn, train_acc=tc / tn, val_loss=vloss, val_acc=mv["acc"],
                   val_bal_acc=mv["bal_acc"], val_macro_f1=mv["macro_f1"], val_auc=mv["auc_macro_ovr"],
                   val_ece=mv["ece"], lr_last=lr_steps[-1][-1], seconds=time.time() - t0)
        ep_rows.append(row)
        new_file = not ep_csv.exists()
        with open(ep_csv, "a", newline="", encoding="utf-8") as f:
            wr = csv.DictWriter(f, fieldnames=list(row.keys()))
            if new_file:
                wr.writeheader()
            wr.writerow(row)
        cur = row[mon]
        improved = best_epoch == 0 or (cur > best_val if higher else cur < best_val)
        if improved:
            best_val, best_epoch = cur, epoch
            ckpt = dict(model=model.state_dict(), optimizer=opt.state_dict(), scheduler=sched.state_dict(),
                        epoch=epoch, cfg=cfg, val_metrics={k: v for k, v in row.items()}, run=run_name)
            torch.save(ckpt, out / "best.pth")
        print(f"ep {epoch:3d}/{cfg['epochs']} | train loss {row['train_loss']:.4f} acc {row['train_acc']:.3f} | "
              f"val loss {vloss:.4f} acc {mv['acc']:.3f} balacc {mv['bal_acc']:.3f} f1 {mv['macro_f1']:.3f} "
              f"auc {mv['auc_macro_ovr']:.3f} | lr {row['lr_last']:.2e} | {row['seconds']:.0f}s"
              f"{'  *best*' if improved else ''}")
        if collect:
            rows = gstats.report(epoch, cfg["dead_thresh"])
            grad_rows += rows
            print_grad_rows(rows)
            with open(out / "grad_report.csv", "w", newline="", encoding="utf-8") as f:
                wr = csv.DictWriter(f, fieldnames=list(grad_rows[0].keys()))
                wr.writeheader()
                wr.writerows(grad_rows)

    # last checkpoint (full)
    torch.save(dict(model=model.state_dict(), optimizer=opt.state_dict(), scheduler=sched.state_dict(),
                    epoch=cfg["epochs"], cfg=cfg, run=run_name), out / "last.pth")

    # ---------------- final evaluation on the test fold ----------------
    results = {}
    pid_te = meta["pid"][te]
    for which in ("best", "last"):
        if which == "best":
            model.load_state_dict(torch.load(out / "best.pth", map_location=device, weights_only=False)["model"])
        else:
            model.load_state_dict(torch.load(out / "last.pth", map_location=device, weights_only=False)["model"])
        prob, y_t, tloss = predict(model, dl_te, device)
        m = compute_metrics(y_t, prob, pid_te)
        m["loss"] = tloss
        results[which] = m
        with open(out / f"predictions_{which}.csv", "w", newline="", encoding="utf-8") as f:
            wr = csv.writer(f)
            wr.writerow(["row", "slice_idx", "pid", "y_true", "y_pred", "p_men", "p_gli", "p_pit"])
            for j, r_ in enumerate(te):
                wr.writerow([int(r_), int(meta["idx"][r_]), pid_te[j], int(y_t[j]), int(prob[j].argmax()),
                             *[f"{v:.5f}" for v in prob[j]]])
        if which == "best":
            plot_confusion(m["confusion"], out / "confusion.png",
                           f"{cfg['mode']} fold {cfg['fold']} - best epoch {best_epoch} (test)")
            plot_roc_pr(y_t, prob, out / "roc.png", out / "pr.png")
            plot_calibration(y_t, prob, out / "calibration.png")
            plot_per_class(m, out / "per_class.png")
            plot_misclassified(images, te, y_t, prob, pid_te, out / "misclassified.png")
    plot_curves(ep_rows, lr_steps, out / "curves.png")
    plot_grad_norms(grad_rows, out / "grad_norms.png")

    results["best_epoch"], results["monitor"], results["best_monitor_value"] = best_epoch, mon, best_val
    results["split"] = info
    with open(out / "metrics.json", "w", encoding="utf-8") as f:
        json.dump(results, f, indent=1)

    b = results["best"]
    print(f"\n=== TEST (best epoch {best_epoch}, selected on {mon}) ===")
    print(f"acc {b['acc']:.4f} | balanced acc {b['bal_acc']:.4f} | macro F1 {b['macro_f1']:.4f} | "
          f"AUC {b['auc_macro_ovr']:.4f} | ECE {b['ece']:.4f} | MCC {b['mcc']:.4f}")
    print(f"patient-level (mean prob over slices): {b['patient_level']}")
    print(f"last epoch: acc {results['last']['acc']:.4f} | balanced acc {results['last']['bal_acc']:.4f}")
    print("per class:", {k: round(v['recall'], 3) for k, v in b["per_class"].items()}, "(recall)")
    print("confusion (rows=true):", b["confusion"])
    print("saved in", out)

    # one line per run in a shared summary table
    summ = Path(cfg["run_root"]) / "runs_summary.csv"
    line = dict(run=run_name, mode=cfg["mode"], fold=cfg["fold"], seed=cfg["seed"], size=cfg["size"],
                input_mode=cfg["input_mode"], fill=cfg["fill"], region_margin=cfg["region_margin"],
                band_in=cfg["band_in"], band_out=cfg["band_out"], band_unit=cfg["band_unit"],
                band_tumor=cfg["band_tumor"], band_op=cfg["band_op"], band_shuffle=cfg["band_shuffle"],
                freeze_below_stride=cfg["freeze_below_stride"], bn_adapt=cfg["bn_adapt"],
                cut_blocks=cfg["cut_blocks"], hidden=cfg["hidden"], dropout=cfg["dropout"],
                epochs=cfg["epochs"], lr_backbone=cfg["lr_backbone"], lr_head=cfg["lr_head"],
                weight_decay=cfg["weight_decay"], augment=cfg["augment"], tag=cfg["tag"],
                trainable_params=n_train_params, best_epoch=best_epoch,
                best_val=round(best_val, 4), test_acc=round(b["acc"], 4),
                test_bal_acc=round(b["bal_acc"], 4), test_macro_f1=round(b["macro_f1"], 4),
                test_auc=round(b["auc_macro_ovr"], 4), test_ece=round(b["ece"], 4),
                test_patient_acc=round(b["patient_level"]["acc"], 4),
                last_test_acc=round(results["last"]["acc"], 4),
                test_slices_with_train_patient=info["test_slices_with_train_patient"])
    new_file = not summ.exists()
    with open(summ, "a", newline="", encoding="utf-8") as f:
        wr = csv.DictWriter(f, fieldnames=list(line.keys()))
        if new_file:
            wr.writeheader()
        wr.writerow(line)
    return results


def parse_cli(cfg):
    for a in sys.argv[1:]:
        if "=" not in a:
            raise SystemExit(f"bad argument '{a}', use key=value")
        k, v = a.split("=", 1)
        if k not in cfg:
            raise SystemExit(f"unknown config key '{k}'. valid: {sorted(cfg)}")
        try:
            v = ast.literal_eval(v)
        except (ValueError, SyntaxError):
            pass
        cfg[k] = v
    return cfg


if __name__ == "__main__":
    cfg = parse_cli(dict(CFG))
    folds = range(cfg["n_splits"]) if cfg["fold"] == "all" else [cfg["fold"]]
    for k in folds:
        c = dict(cfg)
        c["fold"] = int(k)
        run_one(c)
