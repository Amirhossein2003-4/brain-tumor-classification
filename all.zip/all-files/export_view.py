"""
export_view.py - make human-viewable copies of the dataset.

Creates next to the PNG dataset:
    images_view/<class>/<idx>_<pid>.png      8-bit, contrast-normalized (same percentile window as data.py), full resolution
    images_overlay/<class>/<idx>_<pid>.png   same image + tumor border in red

Run:  python export_view.py
(Originals in images/ and masks/ are NOT touched; the model pipeline keeps using them.)
"""
from pathlib import Path

import numpy as np
from PIL import Image

from data import P_HIGH, P_LOW
from splits import ROOT, load_meta


def to_u8(path):
    im = np.array(Image.open(path)).astype(np.float32)
    lo, hi = np.percentile(im, [P_LOW, P_HIGH])
    return (np.clip((im - lo) / (hi - lo + 1e-8), 0, 1) * 255).astype(np.uint8)


def border(mask):
    """1-pixel inner border of a boolean mask (no scipy needed)."""
    m = mask.astype(bool)
    p = np.pad(m, 1)
    inner = p[1:-1, 1:-1] & p[:-2, 1:-1] & p[2:, 1:-1] & p[1:-1, :-2] & p[1:-1, 2:]
    return m & ~inner


if __name__ == "__main__":
    root = Path(ROOT)
    meta = load_meta(root)
    names = {0: "meningioma", 1: "glioma", 2: "pituitary"}
    for i in range(len(meta["idx"])):
        cls, name = names[int(meta["label"][i])], f"{meta['idx'][i]}_{meta['pid'][i]}.png"
        for d in ("images_view", "images_overlay"):
            (root / d / cls).mkdir(parents=True, exist_ok=True)
        g = to_u8(root / meta["img_path"][i])
        Image.fromarray(g).save(root / "images_view" / cls / name)
        m = np.array(Image.open(root / meta["mask_path"][i])) > 0
        rgb = np.stack([g, g, g], axis=-1)
        rgb[border(m)] = [255, 0, 0]
        Image.fromarray(rgb).save(root / "images_overlay" / cls / name)
        if (i + 1) % 500 == 0:
            print(f"  {i + 1}/{len(meta['idx'])}")
    print("done ->", root / "images_view", "and", root / "images_overlay")
