"""
mask_baseline.py - how much does the tumor SILHOUETTE alone (shape, size, location) say about the class?
No CNN, no images: just hand-made geometric features of the tumor mask + a Random Forest, evaluated on the
same 5 folds for both split types. Runs in about a minute on CPU.

    python mask_baseline.py                 # size 160 cache
    python mask_baseline.py size=224 seed=1      (optional: root=<data folder>)

Output: table (mean +- std over folds) and mask_baseline.csv in the data folder.
"""
import csv
import sys
from pathlib import Path

import numpy as np
from scipy import ndimage
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score

from data import build_cache
from splits import ROOT, load_meta, make_folds

SIZE, SEED = 160, 0


def mask_features(m):
    s = m.shape[0]
    m = m > 0
    area = m.sum()
    if area == 0:
        return [0.0] * 13
    ys, xs = np.nonzero(m)
    cy, cx = ys.mean() / s, xs.mean() / s
    bh, bw = (ys.max() - ys.min() + 1) / s, (xs.max() - xs.min() + 1) / s
    cov = np.cov(np.vstack([xs, ys])) if area > 2 else np.eye(2)
    ev = np.sort(np.linalg.eigvalsh(cov))[::-1]
    elong = float(np.sqrt(ev[0] / max(ev[1], 1e-6)))
    er = ndimage.binary_erosion(m)
    perim = float((m & ~er).sum())
    comps = ndimage.label(m)[1]
    return [area / s ** 2, cx, cy, bw, bh, area / (bw * bh * s ** 2), elong,
            perim / s, perim ** 2 / max(float(area), 1.0), float(comps),
            abs(cx - 0.5), abs(cy - 0.5), float(np.sqrt((cx - 0.5) ** 2 + (cy - 0.5) ** 2))]


def main():
    size, seed, root = SIZE, SEED, ROOT
    for a in sys.argv[1:]:
        k, v = a.split("=")
        if k == "size":
            size = int(v)
        elif k == "seed":
            seed = int(v)
        elif k == "root":
            root = v
    meta = load_meta(root)
    _, masks = build_cache(root, size=size)
    X = np.array([mask_features(m) for m in masks])
    y = meta["label"]
    rows = []
    print(f"features {X.shape} | classes {np.bincount(y).tolist()} | chance balanced acc 0.333")
    for mode in ("slice", "patient"):
        res = []
        for k, (tr, te) in enumerate(make_folds(meta, mode, 5, seed)):
            rf = RandomForestClassifier(300, class_weight="balanced", min_samples_leaf=2, random_state=seed, n_jobs=-1)
            rf.fit(X[tr], y[tr])
            p = rf.predict(X[te])
            res.append((accuracy_score(y[te], p), balanced_accuracy_score(y[te], p), f1_score(y[te], p, average="macro")))
            rows.append(dict(split=mode, fold=k, acc=res[-1][0], bal_acc=res[-1][1], macro_f1=res[-1][2]))
        r = np.array(res)
        print(f"{mode:<8} acc {r[:, 0].mean():.3f}+-{r[:, 0].std():.3f} | balanced acc {r[:, 1].mean():.3f}+-{r[:, 1].std():.3f} "
              f"| macro F1 {r[:, 2].mean():.3f}+-{r[:, 2].std():.3f}")
    out = Path(root) / "mask_baseline.csv"
    with open(out, "w", newline="", encoding="utf-8") as f:
        wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wr.writeheader()
        wr.writerows(rows)
    print("saved", out)


if __name__ == "__main__":
    main()
