"""
splits.py - the two ways of splitting the SAME data that the whole project compares.

  mode="slice"   : random stratified split over slices      (the naive way, leaks)
  mode="patient" : stratified split with all slices of a patient kept together (no leak)

Only numpy + scikit-learn. No torch.
"""
import csv
from pathlib import Path

import numpy as np
from sklearn.model_selection import StratifiedGroupKFold, StratifiedKFold

# ----------------------------- CONFIG ---------------------------------------
ROOT = Path(r"C:\Users\amir\DL\datasets\brain_tumor_png")
N_SPLITS = 5
VAL_FRACTION_FOLDS = 8          # inner val = 1/8 of the training part (~12.5%)
# -----------------------------------------------------------------------------


def load_meta(root=ROOT):
    """Return dict of numpy arrays: idx, label, pid, h, w, img_path, mask_path (row order = idx order)."""
    with open(Path(root) / "meta.csv", newline="", encoding="utf-8") as f:
        rows = sorted(csv.DictReader(f), key=lambda r: int(r["idx"]))
    return dict(
        idx=np.array([int(r["idx"]) for r in rows]),
        label=np.array([int(r["label"]) for r in rows]),
        pid=np.array([r["pid"] for r in rows]),
        h=np.array([int(r["h"]) for r in rows]),
        w=np.array([int(r["w"]) for r in rows]),
        img_path=np.array([r["img_path"] for r in rows]),
        mask_path=np.array([r["mask_path"] for r in rows]),
    )


def _kfold(mode, y, g, n_splits, seed):
    X = np.zeros(len(y))
    if mode == "slice":
        return list(StratifiedKFold(n_splits, shuffle=True, random_state=seed).split(X, y))
    if mode == "patient":
        return list(StratifiedGroupKFold(n_splits, shuffle=True, random_state=seed).split(X, y, g))
    raise ValueError("mode must be 'slice' or 'patient'")


def make_folds(meta, mode, n_splits=N_SPLITS, seed=0):
    """List of (train_idx, test_idx) as ROW indices into meta arrays."""
    return _kfold(mode, meta["label"], meta["pid"], n_splits, seed)


def train_val_split(meta, train_idx, mode, seed=0):
    """
    Inner train/val split for early stopping / model selection.
    IMPORTANT: uses the SAME mode as the outer split, otherwise the validation set
    would leak (or not) differently from the test set and the comparison is unfair.
    """
    sub = _kfold(mode, meta["label"][train_idx], meta["pid"][train_idx], VAL_FRACTION_FOLDS, seed)
    tr, va = sub[0]
    return train_idx[tr], train_idx[va]


def leakage_report(meta, folds, name=""):
    """For every fold: how many test slices belong to a patient that also has slices in train."""
    pid = meta["pid"]
    print(f"\n[{name}] leakage report")
    tot_leaked = 0
    for k, (tr, te) in enumerate(folds):
        shared = set(pid[tr]) & set(pid[te])
        leaked = int(np.isin(pid[te], list(shared)).sum()) if shared else 0
        tot_leaked += leaked
        print(f"  fold {k}: train={len(tr)} test={len(te)} | "
              f"test patients={len(set(pid[te]))} shared-with-train={len(shared)} | "
              f"test slices with same-patient train slice: {leaked}/{len(te)} ({100*leaked/len(te):.1f}%)")
    return tot_leaked


if __name__ == "__main__":
    meta = load_meta()
    print("slices:", len(meta["idx"]), "| patients:", len(set(meta["pid"])))
    for mode in ["slice", "patient"]:
        folds = make_folds(meta, mode, seed=0)
        leakage_report(meta, folds, mode)
        # class balance per fold (test part)
        for k, (_, te) in enumerate(folds):
            c = np.bincount(meta["label"][te], minlength=3)
            print(f"  fold {k} test class counts (men/gli/pit): {c.tolist()}")
    # sanity: patient mode must have zero leakage
    assert leakage_report(meta, make_folds(meta, "patient", seed=1), "patient seed1") == 0
    print("\nOK: patient-level split has zero shared patients.")
