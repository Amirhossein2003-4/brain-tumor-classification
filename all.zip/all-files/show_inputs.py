"""
show_inputs.py - see exactly what the model gets in each input_mode, for one slice per class.
    python show_inputs.py            (size 160 cache; optional: size=224 root=<data folder>)
Saves input_modes_preview.png in the data folder.
"""
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from data import build_cache, make_input  # noqa: E402
from splits import ROOT, load_meta  # noqa: E402

size, root = 160, ROOT
for a in sys.argv[1:]:
    k, v = a.split("=")
    size, root = (int(v), root) if k == "size" else (size, v if k == "root" else root)

meta = load_meta(root)
images, masks = build_cache(root, size=size)
names = ["meningioma", "glioma", "pituitary"]
rows = [int(np.where(meta["label"] == c)[0][len(np.where(meta["label"] == c)[0]) // 2]) for c in range(3)]
modes = [("full", 0), ("tumor_only", 0), ("context_only", 0), ("mask_only", 0)]
fig, ax = plt.subplots(3, 4, figsize=(12, 9))
for r, i in enumerate(rows):
    for c, (mode, margin) in enumerate(modes):
        x = make_input(images[i:i + 1], masks[i:i + 1], mode, "blur", margin)[0].astype(np.float32)
        ax[r, c].imshow(x, cmap="gray", vmin=0, vmax=1)
        ax[r, c].set_title(f"{names[meta['label'][i]]} - {mode}", fontsize=9)
        ax[r, c].axis("off")
plt.tight_layout()
out = f"{root}/input_modes_preview.png"
plt.savefig(out, dpi=120)
print("saved", out)
