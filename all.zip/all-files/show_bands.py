"""
show_bands.py - LOOK at the band conditions before spending any compute on them.

    python show_bands.py                    # preset small, one slice per class
    python show_bands.py preset=full
    python show_bands.py preset=full slice=123    # a specific slice_idx (all three rows then show that slice)
Saves band_preview_<preset>.png in the data folder.
"""
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from band_presets import PRESETS  # noqa: E402
from data import build_cache, make_input  # noqa: E402
from splits import ROOT, load_meta  # noqa: E402

opt = dict(preset="small", size="160", root=str(ROOT), slice=None)
for a in sys.argv[1:]:
    k, v = a.split("=", 1)
    opt[k] = v
conds = PRESETS[opt["preset"]]
size, root = int(opt["size"]), opt["root"]
meta = load_meta(root)
images, masks = build_cache(root, size=size)
if opt["slice"]:
    rows = [int(np.where(meta["idx"] == int(opt["slice"]))[0][0])]
else:
    rows = [int(np.where(meta["label"] == c)[0][len(np.where(meta["label"] == c)[0]) // 2]) for c in range(3)]
cols = 5
nrow_per = int(np.ceil(len(conds) / cols))
fig, ax = plt.subplots(nrow_per * len(rows), cols, figsize=(2.6 * cols, 2.8 * nrow_per * len(rows)))
ax = np.atleast_2d(ax)
for a in ax.flat:
    a.axis("off")
for r, i in enumerate(rows):
    for j, c in enumerate(conds):
        x = make_input(images[i:i + 1], masks[i:i + 1], c["mode"], c["fill"], c["margin"], band=c["band"])[0].astype(np.float32)
        a = ax[r * nrow_per + j // cols, j % cols]
        a.imshow(x, cmap="gray", vmin=0, vmax=1)
        a.set_title(c["name"], fontsize=8)
plt.tight_layout()
out = f"{root}/band_preview_{opt['preset']}.png"
plt.savefig(out, dpi=110)
print("saved", out)
