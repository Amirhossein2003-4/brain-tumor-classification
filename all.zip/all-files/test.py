import numpy as np, matplotlib.pyplot as plt
from PIL import Image

D = r"C:\Users\amir\DL\datasets\brain_tumor_png"
fig, ax = plt.subplots(2, 4, figsize=(14, 7))
for k, i in enumerate([1, 700, 1500, 3000]):
    im = np.array(Image.open(f"{D}/images/{i}.png")).astype(np.float32)
    m = np.array(Image.open(f"{D}/masks/{i}.png")) > 0
    lo, hi = np.percentile(im, [1, 99.5])
    v = np.clip((im - lo) / (hi - lo + 1e-8), 0, 1)
    ax[0, k].imshow(v, cmap="gray"); ax[0, k].set_title(f"{i}  max={im.max():.0f}")
    ax[1, k].imshow(v, cmap="gray"); ax[1, k].contour(m, colors="r", linewidths=0.8)
    for a in ax[:, k]: a.axis("off")
plt.tight_layout(); plt.show()