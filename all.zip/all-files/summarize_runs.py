"""
summarize_runs.py - compare the input representations (full / tumor_only / context_only / ...) class by class,
with uncertainty that respects the fact that slices of one patient are NOT independent observations.

    python summarize_runs.py                         # patient split, best-epoch predictions, 1000 bootstrap draws
    python summarize_runs.py mode=slice              # same for the random-slice runs
    python summarize_runs.py epochs=30 boot=2000
    python summarize_runs.py plane_csv=C:\\Users\\amir\\DL\\datasets\\brain_tumor_png\\plane_clusters.csv

What it does
  1. Finds the finished runs in run_root (config.json + predictions_<which>.csv) and groups them into conditions
     (input_mode, margin, fill, seed, epochs, tag). Runs of one condition are the CV folds.
  2. Pools the out-of-fold test predictions of the folds that every condition has in common.
  3. Metrics per condition: AUC (one-vs-rest) and recall for each class, balanced accuracy, macro F1, ECE.
  4. Confidence intervals: PATIENT-LEVEL bootstrap (patients are resampled with replacement inside each class;
     all their slices travel together). The same resampled patients are used for every condition, so the
     differences between conditions are paired.
  5. Paired contrasts (e.g. context_only - tumor_only) per class, and the difference of those contrasts
     between classes, which is the question "does the usefulness of the context differ between classes?".
  6. Per-fold spread, and (optional) results by scan plane, and the geometry-only random forest from
     mask_baseline.py as an extra condition when its out-of-fold file exists.

What the numbers are NOT: causal contributions of tissues. They are performance differences between models
trained on different input representations of the same slices.
"""
import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from sklearn.metrics import adjusted_rand_score, roc_auc_score  # noqa: E402,F401

CLASS_NAMES = ["meningioma", "glioma", "pituitary"]
SHORT = ["men", "gli", "pit"]

# ------------------------------ settings (override with key=value) ------------------------------
OPT = dict(
    run_root=r"C:\Users\amir\DL\runs\brain_tumor",
    data_root=r"C:\Users\amir\DL\datasets\brain_tumor_png",
    mode="patient",          # which split type to analyse
    which="best",            # best | last  (which checkpoint's test predictions)
    epochs=None,             # keep only runs trained for this many epochs (e.g. 30)
    include=None,            # comma separated substrings; keep only matching condition labels
    boot=1000,               # bootstrap draws
    boot_seed=0,
    geometry=True,           # add the geometry-only random forest (mask_baseline.py) if available
    plane_csv=None,          # csv with columns slice_idx,plane (from estimate_plane.py)
)
# -------------------------------------------------------------------------------------------------


def parse_cli():
    for a in sys.argv[1:]:
        k, v = a.split("=", 1)
        if k not in OPT:
            raise SystemExit(f"unknown option {k}; valid: {sorted(OPT)}")
        if k in ("epochs", "boot", "boot_seed"):
            v = int(v)
        elif k == "geometry":
            v = v.lower() in ("1", "true", "yes")
        OPT[k] = v


def read_pred(path):
    with open(path, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    return dict(
        slice_idx=np.array([int(r["slice_idx"]) for r in rows]),
        pid=np.array([r["pid"] for r in rows]),
        y=np.array([int(r["y_true"]) for r in rows]),
        P=np.array([[float(r["p_men"]), float(r["p_gli"]), float(r["p_pit"])] for r in rows]),
    )


def disp(k):
    return {"bal_acc": "balacc", "macro_f1": "macroF1", "auc_macro": "macro"}.get(k, k.split("_", 1)[-1])


def label_of(key):
    input_mode, fill, margin, seed, epochs, tag, bandsig = key
    s = input_mode
    if input_mode == "band":
        op, lo, hi, unit, tum, shuf = bandsig
        s = f"band:{op}[{lo}-{hi}{'rel' if unit == 'rel' else 'px'}]{'+T' if tum else ''}{'+shuf' if shuf else ''}"
    if margin:
        s += f"+m{margin}"
    if input_mode in ("context_only", "band") and fill != "blur" and not (input_mode == "band" and fill == "zero"):
        s += f"[{fill}]"
    if tag:
        s += f"#{tag}"
    return f"{s} (e{epochs},s{seed})"


def load_conditions():
    root = Path(OPT["run_root"])
    found = defaultdict(dict)
    for d in sorted(root.iterdir()):
        cj, pj = d / "config.json", d / f"predictions_{OPT['which']}.csv"
        if not (cj.exists() and pj.exists()):
            continue
        cfg = json.load(open(cj, encoding="utf-8"))["cfg"]
        if cfg["mode"] != OPT["mode"]:
            continue
        if OPT["epochs"] and int(cfg["epochs"]) != OPT["epochs"]:
            continue
        im = cfg.get("input_mode", "full")
        bandsig = ((cfg.get("band_op", "keep"), cfg.get("band_in", 0), cfg.get("band_out", 15), cfg.get("band_unit", "px512"),
                    bool(cfg.get("band_tumor", False)), bool(cfg.get("band_shuffle", False))) if im == "band" else ())
        key = (im, cfg.get("fill", "blur") if im in ("context_only", "band") else "-", int(cfg.get("region_margin", 0)),
               int(cfg["seed"]), int(cfg["epochs"]), cfg.get("tag", ""), bandsig)
        found[key][int(cfg["fold"])] = d          # sorted by name = by time: a later duplicate replaces an earlier one
    conds = {}
    for key, folds in found.items():
        lab = label_of(key)
        if OPT["include"] and not any(t in lab for t in OPT["include"].split(",")):
            continue
        parts = []
        for k, d in sorted(folds.items()):
            r = read_pred(d / f"predictions_{OPT['which']}.csv")
            r["fold"] = np.full(len(r["y"]), k)
            parts.append(r)
        conds[lab] = {k: np.concatenate([p[k] for p in parts]) for k in parts[0]}
        conds[lab]["n_folds"] = len(folds)
    return conds


def add_geometry(conds):
    seed = 0
    p = Path(OPT["data_root"]) / f"mask_baseline_oof_{OPT['mode']}_s{seed}.csv"
    if not (OPT["geometry"] and p.exists()):
        return
    with open(p, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    conds["geometry-RF (13 mask features)"] = dict(
        slice_idx=np.array([int(r["slice_idx"]) for r in rows]), pid=np.array([r["pid"] for r in rows]),
        y=np.array([int(r["y_true"]) for r in rows]),
        P=np.array([[float(r["p_men"]), float(r["p_gli"]), float(r["p_pit"])] for r in rows]),
        fold=np.array([int(r["fold"]) for r in rows]), n_folds=len({r["fold"] for r in rows}))


def align(conds):
    common = None
    for c in conds.values():
        s = set(c["slice_idx"].tolist())
        common = s if common is None else common & s
    common = np.array(sorted(common))
    out = {}
    for lab, c in conds.items():
        order = np.argsort(c["slice_idx"])
        idx = c["slice_idx"][order]
        keep = np.isin(idx, common)
        out[lab] = {k: (v[order][keep] if isinstance(v, np.ndarray) else v) for k, v in c.items()}
    return out, common


def nanmean_safe(x):
    x = np.array(x, dtype=float)
    x = x[~np.isnan(x)]
    return float(x.mean()) if len(x) else float("nan")


def fast_metrics(y, P, pred, idx):
    yy, pp, pr = y[idx], P[idx], pred[idx]
    m = {}
    k = 3
    rec, f1 = [], []
    for c in range(k):
        tp = np.sum((yy == c) & (pr == c))
        fn = np.sum((yy == c) & (pr != c))
        fp = np.sum((yy != c) & (pr == c))
        rec.append(tp / (tp + fn) if (tp + fn) > 0 else np.nan)       # class absent in this subset -> undefined
        f1.append(2 * tp / (2 * tp + fp + fn) if (tp + fn) > 0 else np.nan)
        pos = (yy == c)
        m[f"auc_{SHORT[c]}"] = roc_auc_score(pos, pp[:, c]) if 0 < pos.sum() < len(yy) else np.nan
        m[f"rec_{SHORT[c]}"] = rec[-1]
    m["auc_macro"] = nanmean_safe([m[f"auc_{s}"] for s in SHORT])
    m["bal_acc"] = nanmean_safe(rec)
    m["macro_f1"] = nanmean_safe(f1)
    return m


def ece(y, P, bins=10):
    conf, pred = P.max(1), P.argmax(1)
    acc = (pred == y).astype(float)
    edges = np.linspace(0, 1, bins + 1)
    e = 0.0
    for lo, hi in zip(edges[:-1], edges[1:]):
        mk = (conf > lo) & (conf <= hi)
        if mk.any():
            e += mk.mean() * abs(acc[mk].mean() - conf[mk].mean())
    return float(e)


def patient_acc(y, P, pid):
    up = np.unique(pid)
    ok = 0
    for u in up:
        m = pid == u
        ok += int(P[m].mean(0).argmax() == y[m][0])
    return ok / len(up)


def bootstrap(conds, common_n, boot, seed):
    labs = list(conds)
    ref = conds[labs[0]]
    y, pid = ref["y"], ref["pid"]
    preds = {l: conds[l]["P"].argmax(1) for l in labs}
    upid = np.unique(pid)
    groups = {u: np.where(pid == u)[0] for u in upid}
    pcls = {u: int(y[groups[u][0]]) for u in upid}
    by_class = [np.array([u for u in upid if pcls[u] == c]) for c in range(3)]
    rng = np.random.default_rng(seed)
    draws = {l: [] for l in labs}
    for b in range(boot):
        sel = np.concatenate([rng.choice(bc, size=len(bc), replace=True) for bc in by_class if len(bc)])
        idx = np.concatenate([groups[u] for u in sel])
        for l in labs:
            draws[l].append(fast_metrics(y, conds[l]["P"], preds[l], idx))
    keys = list(draws[labs[0]][0].keys())
    return {l: {k: np.array([d[k] for d in draws[l]]) for k in keys} for l in labs}, keys


def ci(a):
    a = a[~np.isnan(a)]
    return np.percentile(a, 2.5), np.percentile(a, 97.5)


def main():
    parse_cli()
    conds = load_conditions()
    if not conds:
        raise SystemExit("no finished runs found (need config.json + predictions_*.csv in run_root)")
    print(f"split mode: {OPT['mode']} | checkpoint: {OPT['which']} | run_root: {OPT['run_root']}")
    print("conditions found (label: folds):", {k: v["n_folds"] for k, v in conds.items()})
    top = max(v["n_folds"] for v in conds.values())
    dropped = [k for k, v in conds.items() if v["n_folds"] < top]
    if dropped:
        print(f"WARNING: ignoring conditions with fewer than {top} folds (use include=/epochs= to select): {dropped}")
        conds = {k: v for k, v in conds.items() if v["n_folds"] == top}
    add_geometry(conds)
    conds, common = align(conds)
    labs = list(conds)
    ref = conds[labs[0]]
    n_pat = len(np.unique(ref["pid"]))
    print(f"\ncommon out-of-fold coverage: {len(common)} slices from {n_pat} patients "
          f"(class counts of patients: {[int(len({p for p, yv in zip(ref['pid'], ref['y']) if yv == c})) for c in range(3)]})")
    if top < 5:
        print(f"NOTE: only {top} of 5 folds are available, so only {n_pat} patients are covered: the intervals "
              "are wide and everything is preliminary.")

    draws, keys = bootstrap(conds, len(common), OPT["boot"], OPT["boot_seed"])
    rows_out = []

    def pt(l, k):
        idx = np.arange(len(common))
        return fast_metrics(conds[l]["y"], conds[l]["P"], conds[l]["P"].argmax(1), idx)[k]

    print("\n=== per-condition metrics (point estimate [95% patient-level bootstrap CI]) ===")
    for l in labs:
        c = conds[l]
        print(f"\n{l}   folds={c['n_folds']}")
        for grp, ks in (("AUC (OvR)", [f"auc_{s}" for s in SHORT] + ["auc_macro"]),
                        ("recall", [f"rec_{s}" for s in SHORT] + ["bal_acc"]),
                        ("other", ["macro_f1"])):
            cells = []
            for k in ks:
                lo, hi = ci(draws[l][k])
                v = pt(l, k)
                cells.append(f"{disp(k)}: {v:.3f} [{lo:.3f},{hi:.3f}]")
                rows_out.append(dict(condition=l, metric=k, value=v, lo=lo, hi=hi))
            print(f"  {grp:<10} " + " | ".join(cells))
        e = ece(c["y"], c["P"])
        pa = patient_acc(c["y"], c["P"], c["pid"])
        print(f"  ECE {e:.3f} | patient-level accuracy (mean prob over slices) {pa:.3f} over {n_pat} patients")
        rows_out += [dict(condition=l, metric="ece", value=e, lo=np.nan, hi=np.nan),
                     dict(condition=l, metric="patient_acc", value=pa, lo=np.nan, hi=np.nan)]

    # paired contrasts
    def find(prefix):
        m = [l for l in labs if l.startswith(prefix)]
        return m[0] if m else None
    full, tum, ctx = find("full"), find("tumor_only"), find("context_only")
    contrasts = [(a, b) for a, b in ((full, ctx), (full, tum), (ctx, tum)) if a and b]
    if contrasts:
        print("\n=== paired contrasts (A - B), AUC per class, 95% CI; * = interval excludes 0 ===")
    for a, b in contrasts:
        cells = []
        for k in [f"auc_{s}" for s in SHORT] + ["auc_macro", "bal_acc"]:
            d = draws[a][k] - draws[b][k]
            lo, hi = ci(d)
            v = pt(a, k) - pt(b, k)
            star = "*" if (lo > 0 or hi < 0) else " "
            cells.append(f"{disp(k)}: {v:+.3f} [{lo:+.3f},{hi:+.3f}]{star}")
            rows_out.append(dict(condition=f"{a} - {b}", metric=k, value=v, lo=lo, hi=hi))
        print(f"  {a}  -  {b}\n     " + " | ".join(cells))
    twins = [(l.replace("+shuf", "", 1), l) for l in labs if "+shuf" in l and l.replace("+shuf", "", 1) in labs]
    if twins:
        print("\n=== structure control: real band minus its shuffled twin (same geometry and histogram), AUC, 95% CI; * = excludes 0 ===")
        for a_, b_ in twins:
            cells = []
            for k in [f"auc_{s_}" for s_ in SHORT] + ["auc_macro", "bal_acc"]:
                d = draws[a_][k] - draws[b_][k]
                lo, hi = ci(d)
                v = pt(a_, k) - pt(b_, k)
                star = "*" if (lo > 0 or hi < 0) else " "
                cells.append(f"{disp(k)}: {v:+.3f} [{lo:+.3f},{hi:+.3f}]{star}")
                rows_out.append(dict(condition=f"{a_} - {b_}", metric=k, value=v, lo=lo, hi=hi))
            print(f"  {a_}  -  {b_}\n     " + " | ".join(cells))
    het = None
    if ctx and tum:
        print("\n=== does the usefulness of context differ between classes?  (AUC_context - AUC_tumor) per class, "
              "and the differences between classes ===")
        dlt = {s: draws[ctx][f"auc_{s}"] - draws[tum][f"auc_{s}"] for s in SHORT}
        for s in SHORT:
            lo, hi = ci(dlt[s])
            print(f"  {s}: {np.mean(dlt[s]):+.3f} [{lo:+.3f},{hi:+.3f}]")
        het = {}
        for a, b in (("gli", "men"), ("gli", "pit"), ("men", "pit")):
            d = dlt[a] - dlt[b]
            lo, hi = ci(d)
            star = "*" if (lo > 0 or hi < 0) else " "
            print(f"  ({a}) - ({b}): {np.mean(d):+.3f} [{lo:+.3f},{hi:+.3f}]{star}")
            rows_out.append(dict(condition=f"context-tumor AUC contrast: {a}-{b}", metric="heterogeneity",
                                 value=float(np.mean(d)), lo=lo, hi=hi))
            het[(a, b)] = (np.mean(d), lo, hi)
        print("  (many comparisons and few patients per class: treat a star as a hint, not a conclusion)")

    # per fold spread
    print("\n=== per-fold spread of balanced accuracy / macro F1 (one number per fold) ===")
    for l in labs:
        c = conds[l]
        vals = []
        for f_ in sorted(np.unique(c["fold"])):
            m = c["fold"] == f_
            fm = fast_metrics(c["y"], c["P"], c["P"].argmax(1), np.where(m)[0])
            vals.append((fm["bal_acc"], fm["macro_f1"]))
        v = np.array(vals)
        print(f"  {l:<34} bal_acc {v[:, 0].mean():.3f}+-{v[:, 0].std():.3f} {np.round(v[:, 0], 3).tolist()} | "
              f"macro F1 {v[:, 1].mean():.3f}+-{v[:, 1].std():.3f}")

    # scan plane strata
    if OPT["plane_csv"]:
        with open(OPT["plane_csv"], newline="", encoding="utf-8") as f:
            pl = {int(r["slice_idx"]): r["plane"] for r in csv.DictReader(f)}
        plane = np.array([pl.get(int(s), "") for s in common])
        print("\n=== by scan plane (point estimates only; n = slices) ===")
        names = sorted({p for p in plane if p})
        for p in names:
            m = plane == p
            ycount = np.bincount(ref["y"][m], minlength=3).tolist()
            print(f"  plane {p}: n={int(m.sum())} class counts (men/gli/pit) {ycount}")
        for l in labs:
            cells = []
            for p in names:
                m = np.where(plane == p)[0]
                fm = fast_metrics(conds[l]["y"], conds[l]["P"], conds[l]["P"].argmax(1), m)
                cells.append(f"{p}: balacc {fm['bal_acc']:.3f} rec {fm['rec_men']:.2f}/{fm['rec_gli']:.2f}/{fm['rec_pit']:.2f}")
            print(f"  {l:<34} " + " | ".join(cells))

    out_csv = Path(OPT["run_root"]) / f"summary_{OPT['mode']}.csv"
    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        wr = csv.DictWriter(f, fieldnames=["condition", "metric", "value", "lo", "hi"])
        wr.writeheader()
        wr.writerows(rows_out)

    # figure: per-class AUC with CI  +  context-tumor contrast per class
    fig, ax = plt.subplots(1, 2, figsize=(14, 5))
    w = 0.8 / len(labs)
    for j, l in enumerate(labs):
        v = [pt(l, f"auc_{s}") for s in SHORT]
        err = np.array([[v[i] - ci(draws[l][f"auc_{s}"])[0], ci(draws[l][f"auc_{s}"])[1] - v[i]]
                        for i, s in enumerate(SHORT)]).T
        ax[0].bar(np.arange(3) + (j - (len(labs) - 1) / 2) * w, v, w, yerr=err, capsize=2, label=l)
    ax[0].set_xticks(range(3))
    ax[0].set_xticklabels(CLASS_NAMES)
    ax[0].set_ylim(0.5, 1.02)
    ax[0].set_ylabel("AUC (one-vs-rest), pooled out-of-fold")
    ax[0].legend(fontsize=7)
    ax[0].grid(alpha=0.3, axis="y")
    ax[0].set_title(f"{OPT['mode']} split - 95% patient-level bootstrap CI")
    if ctx and tum:
        m_ = [np.mean(dlt[s]) for s in SHORT]
        e_ = np.array([[np.mean(dlt[s]) - ci(dlt[s])[0], ci(dlt[s])[1] - np.mean(dlt[s])] for s in SHORT]).T
        ax[1].bar(range(3), m_, yerr=e_, capsize=4, color="tab:purple")
        ax[1].axhline(0, color="k", lw=0.6)
        ax[1].set_xticks(range(3))
        ax[1].set_xticklabels(CLASS_NAMES)
        ax[1].set_ylabel("AUC(context_only) - AUC(tumor_only)")
        ax[1].set_title("usefulness of context relative to tumor, per class")
        ax[1].grid(alpha=0.3, axis="y")
    plt.tight_layout()
    out_png = Path(OPT["run_root"]) / f"summary_{OPT['mode']}.png"
    plt.savefig(out_png, dpi=130)
    plt.close()
    print(f"\nsaved {out_csv} and {out_png}")
    print("Reminder: these are performance differences between models trained on different inputs, "
          "not causal contributions of tissues.")


if __name__ == "__main__":
    main()
