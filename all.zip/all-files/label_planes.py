"""
label_planes.py - label the scan plane of a small random sample BY EYE (about 10 minutes), then let a simple
classifier propagate the labels to all slices and tell you how reliable that is.

    python label_planes.py           # label (resumable). Type q to stop and fit.
    python label_planes.py fit       # skip labelling, just (re)fit from the labels already saved
    python label_planes.py n=150     # how many slices to label in total (default 120)

How labelling works: a window shows 12 slices numbered 1..12. Type 12 letters in the terminal, left to right,
top to bottom, then Enter:   a = axial   c = coronal   s = sagittal   x = unsure / skip   q = quit and fit
(axial: head seen from above, oval; sagittal: side profile with the face; coronal: front view).
Close the window or just leave it open; the script moves on after your answer.

Outputs in the data folder:
    plane_labels_manual.csv    your labels (slice_idx, plane)
    plane_labels.csv           slice_idx, pid, plane, confidence   for ALL slices (plane empty if confidence < 0.8)
Use it with:  python summarize_runs.py epochs=30 plane_csv=<data folder>\\plane_labels.csv
The fit prints a patient-grouped cross-validated accuracy: if it is below about 0.9, do not use the plane labels.
"""
import csv
import sys
from pathlib import Path

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import GroupKFold, cross_val_predict
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

import matplotlib
import matplotlib.pyplot as plt  # noqa: E402

from data import build_cache  # noqa: E402
from splits import ROOT, load_meta  # noqa: E402

OPT = dict(root=str(ROOT), size=160, n=120, seed=0)
args = []
for a in sys.argv[1:]:
    if "=" in a:
        k, v = a.split("=", 1)
        if k not in OPT:
            raise SystemExit(f"unknown option {k}")
        OPT[k] = v if k == "root" else int(v)
    else:
        args.append(a)

root = Path(OPT["root"])
meta = load_meta(root)
LAB = {"a": "axial", "c": "coronal", "s": "sagittal"}
man_file = root / "plane_labels_manual.csv"


def load_manual():
    if not man_file.exists():
        return {}
    with open(man_file, newline="", encoding="utf-8") as f:
        return {int(r["slice_idx"]): r["plane"] for r in csv.DictReader(f)}


def save_manual(d):
    with open(man_file, "w", newline="", encoding="utf-8") as f:
        wr = csv.writer(f)
        wr.writerow(["slice_idx", "plane"])
        for k, v in sorted(d.items()):
            wr.writerow([k, v])


def label_session():
    images, _ = build_cache(root, size=OPT["size"])
    manual = load_manual()
    rng = np.random.default_rng(OPT["seed"])
    # stratified over the three tumor classes so every class gets looked at
    order = []
    per = [rng.permutation(np.where(meta["label"] == c)[0]).tolist() for c in range(3)]
    while any(per):
        for c in range(3):
            if per[c]:
                order.append(per[c].pop())
    todo = [i for i in order if int(meta["idx"][i]) not in manual][: max(OPT["n"] - len(manual), 0)]
    print(f"{len(manual)} labels exist; {len(todo)} more to label (target {OPT['n']}). Letters: a c s x, q = quit.")
    for page in range(0, len(todo), 12):
        ids = todo[page:page + 12]
        fig, ax = plt.subplots(3, 4, figsize=(10, 7.5))
        for a in ax.flat:
            a.axis("off")
        for j, i in enumerate(ids):
            ax.flat[j].imshow(images[i].astype(np.float32), cmap="gray", vmin=0, vmax=1)
            ax.flat[j].set_title(str(j + 1), fontsize=14)
        plt.tight_layout()
        try:
            plt.show(block=False)
            plt.pause(0.3)
        except Exception:  # noqa: BLE001
            pass
        while True:
            s = input(f"page {page // 12 + 1}: {len(ids)} letters> ").strip().lower().replace(" ", "")
            if s == "q":
                plt.close("all")
                save_manual(manual)
                return manual
            if len(s) == len(ids) and all(ch in "acsx" for ch in s):
                break
            print(f"  need exactly {len(ids)} letters from a/c/s/x (or q)")
        for i, ch in zip(ids, s):
            if ch in LAB:
                manual[int(meta["idx"][i])] = LAB[ch]
        save_manual(manual)
        plt.close("all")
    return manual


def fit(manual):
    emb_file = root / f"plane_embeddings_{OPT['size']}.npy"
    if not emb_file.exists():
        raise SystemExit(f"{emb_file} not found: run estimate_plane.py once first (it creates the embeddings).")
    E = np.load(emb_file)
    pos = {int(s): i for i, s in enumerate(meta["idx"])}
    li = np.array([pos[s] for s in manual])
    y = np.array([manual[s] for s in manual])
    counts = {p: int((y == p).sum()) for p in ("axial", "coronal", "sagittal")}
    print("labels per plane:", counts)
    if min(counts.values()) < 8:
        raise SystemExit("need at least ~8 labels of each plane to fit; label more (python label_planes.py n=200)")
    groups = meta["pid"][li]
    clf = make_pipeline(StandardScaler(), LogisticRegression(C=0.1, max_iter=2000))
    cv = cross_val_predict(clf, E[li], y, cv=GroupKFold(n_splits=min(5, len(set(groups)))), groups=groups)
    acc = float((cv == y).mean())
    print(f"patient-grouped cross-validated accuracy of the plane classifier: {acc:.3f}")
    names = ["axial", "coronal", "sagittal"]
    print("confusion (rows = your label, cols = predicted; order axial, coronal, sagittal):")
    print(confusion_matrix(y, cv, labels=names))
    if acc < 0.9:
        print("WARNING: below 0.9 - the plane labels are NOT reliable enough; label more images or do not use them.")
    clf.fit(E[li], y)
    P = clf.predict_proba(E)
    cls = list(clf.classes_)
    best = P.argmax(1)
    conf = P.max(1)
    plane = np.array([cls[b] if c >= 0.8 else "" for b, c in zip(best, conf)])
    for s, p in manual.items():          # your own labels win
        plane[pos[s]] = p
        conf[pos[s]] = 1.0
    out = root / "plane_labels.csv"
    with open(out, "w", newline="", encoding="utf-8") as f:
        wr = csv.writer(f)
        wr.writerow(["slice_idx", "pid", "plane", "confidence"])
        for i in range(len(plane)):
            wr.writerow([int(meta["idx"][i]), meta["pid"][i], plane[i], f"{conf[i]:.3f}"])
    print("predicted plane counts (confidence >= 0.8):", {p: int((plane == p).sum()) for p in names},
          "| left empty:", int((plane == "").sum()))
    print("class x plane table (rows meningioma, glioma, pituitary; cols axial, coronal, sagittal):")
    print(np.array([[int(((meta['label'] == c) & (plane == p)).sum()) for p in names] for c in range(3)]))
    print("saved", out)


if __name__ == "__main__":
    manual = load_manual() if "fit" in args else label_session()
    if manual:
        fit(manual)
    else:
        print("no labels yet")
