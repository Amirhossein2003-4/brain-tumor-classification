"""
eval_ablation.py - TEST-TIME ablation of an already trained run. Inference only: no training, light on the laptop.

    python eval_ablation.py "C:\\Users\\amir\\DL\\runs\\brain_tumor\\<run folder>"            # uses best.pth
    python eval_ablation.py "<run folder>" last                                              # uses last.pth

The TEST slices of that run's own split are shown to the trained model in several forms:
    full | tumor_only | context_only | context_only (tumor + 5 px rim removed) | mask_only
and the metrics are written to <run folder>\\ablation_testtime.csv and ablation_testtime.png.

How to read it: the model was trained on FULL images, so the other inputs are out-of-distribution for it.
The drop tells you how much THIS model relies on each part. It does NOT tell you how informative each part is
by itself - for that, retrain on that input (train.py input_mode=...). Also look at 'pred_counts': if the model
collapses to one class, the number is mostly a distribution-shift effect.
"""
import csv
import sys
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

import train as T  # noqa: E402
from data import BrainTumorDataset, build_cache, make_input  # noqa: E402
from splits import load_meta  # noqa: E402

MODES = [("full", 0), ("tumor_only", 0), ("context_only", 0), ("context_only", 5), ("mask_only", 0)]


def main():
    if len(sys.argv) < 2:
        raise SystemExit("usage: python eval_ablation.py <run folder> [best|last]")
    run = Path(sys.argv[1])
    which = sys.argv[2] if len(sys.argv) > 2 else "best"
    ck = torch.load(run / f"{which}.pth", map_location="cpu", weights_only=False)
    cfg = dict(ck["cfg"])
    cfg["pretrained"] = False                      # weights come from the checkpoint
    print(f"run {run.name} | checkpoint {which} (epoch {ck['epoch']}) | split {cfg['mode']} fold {cfg['fold']}")

    meta = load_meta(cfg["data_root"])
    images, masks = build_cache(cfg["data_root"], size=cfg["size"])
    _, _, te, _ = T.get_fold(meta, cfg)
    model = T.Net(cfg)
    model.load_state_dict(ck["model"])
    model.eval()
    img_te, msk_te = images[te], masks[te]
    y_te, pid_te = meta["label"][te], meta["pid"][te]

    rows = []
    for mode, margin in MODES:
        inp = make_input(img_te, msk_te, mode, "blur", margin)
        dl = DataLoader(BrainTumorDataset(inp, y_te, np.arange(len(te))), batch_size=64)
        prob, y, _ = T.predict(model, dl, "cpu")
        m = T.compute_metrics(y, prob, pid_te)
        name = mode + (f"+rim{margin}" if margin else "")
        rows.append(dict(input=name, acc=m["acc"], bal_acc=m["bal_acc"], macro_f1=m["macro_f1"],
                         auc=m["auc_macro_ovr"], ece=m["ece"], patient_acc=m["patient_level"]["acc"],
                         recall_men=m["per_class"]["meningioma"]["recall"],
                         recall_gli=m["per_class"]["glioma"]["recall"],
                         recall_pit=m["per_class"]["pituitary"]["recall"],
                         pred_counts=str(np.bincount(prob.argmax(1), minlength=3).tolist())))
        r = rows[-1]
        print(f"  {name:<22} acc {r['acc']:.3f} balacc {r['bal_acc']:.3f} f1 {r['macro_f1']:.3f} "
              f"auc {r['auc']:.3f} | recall men/gli/pit {r['recall_men']:.2f}/{r['recall_gli']:.2f}/"
              f"{r['recall_pit']:.2f} | predicted {r['pred_counts']}")

    with open(run / "ablation_testtime.csv", "w", newline="", encoding="utf-8") as f:
        wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wr.writeheader()
        wr.writerows(rows)
    names = [r["input"] for r in rows]
    x = np.arange(len(rows))
    fig, ax = plt.subplots(figsize=(9, 4.5))
    for k, key in enumerate(["acc", "bal_acc", "macro_f1"]):
        ax.bar(x + (k - 1) * 0.27, [r[key] for r in rows], 0.27, label=key)
    ax.axhline(1 / 3, color="gray", ls=":", lw=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(names, rotation=15)
    ax.set_ylim(0, 1.05)
    ax.legend()
    ax.grid(alpha=0.3, axis="y")
    ax.set_title(f"test-time ablation of a trained model ({cfg['mode']} split, fold {cfg['fold']})")
    plt.tight_layout()
    plt.savefig(run / "ablation_testtime.png", dpi=130)
    plt.close()
    print("saved ablation_testtime.csv/.png in", run)


if __name__ == "__main__":
    main()
