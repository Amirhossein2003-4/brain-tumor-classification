"""
prep_data.py  -  convert the Cheng brain-tumor .mat files (figshare 1512427)
into PNG images + masks + one metadata CSV.

Run (PowerShell, from causal_env):
    pip install h5py pillow scipy numpy
    python prep_data.py

Output (default):
    C:\\Users\\amir\\DL\\datasets\\brain_tumor_png\\
        images\\<idx>.png      16-bit grayscale, RAW intensities (no normalization)
        masks\\<idx>.png       8-bit, 255 = tumor
        meta.csv              idx,label,label_name,pid,h,w,img_path,mask_path
"""
import argparse
import csv
import re
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
from PIL import Image

# ----------------------------- CONFIG ---------------------------------------
SRC = Path(r"C:\Users\amir\DL\datasets\1512427")
DST = Path(r"C:\Users\amir\DL\datasets\brain_tumor_png")
LABEL_NAMES = {0: "meningioma", 1: "glioma", 2: "pituitary"}  # file labels are 1/2/3
# -----------------------------------------------------------------------------


def read_mat(path):
    """Return dict(label, pid, image, mask). Handles both v7.3 (HDF5) and older v7."""
    try:
        import h5py
        with h5py.File(path, "r") as f:
            d = f["cjdata"]
            label = int(np.array(d["label"]).squeeze())
            pid = "".join(chr(int(c)) for c in np.array(d["PID"]).flatten())
            image = np.array(d["image"]).T      # MATLAB is column-major -> transpose
            mask = np.array(d["tumorMask"]).T
    except OSError:                             # not an HDF5 file -> older .mat
        from scipy.io import loadmat
        m = loadmat(str(path), struct_as_record=False, squeeze_me=True)["cjdata"]
        label, pid = int(m.label), str(m.PID)
        image, mask = np.asarray(m.image), np.asarray(m.tumorMask)
    return dict(label=label, pid=pid, image=image, mask=mask)


def list_mat_files(src):
    files = [p for p in src.glob("brainTumorDataPublic_*/*.mat")]
    files.sort(key=lambda p: int(re.sub(r"\D", "", p.stem) or 0))
    return files


def convert(src, dst):
    (dst / "images").mkdir(parents=True, exist_ok=True)
    (dst / "masks").mkdir(parents=True, exist_ok=True)
    files = list_mat_files(src)
    if not files:
        raise SystemExit(f"No .mat files found under {src}")
    print(f"found {len(files)} .mat files")

    rows = []
    for i, p in enumerate(files):
        r = read_mat(p)
        idx = int(re.sub(r"\D", "", p.stem))
        img = np.clip(r["image"], 0, 65535).astype(np.uint16)
        msk = (np.asarray(r["mask"]) > 0).astype(np.uint8) * 255
        Image.fromarray(img).save(dst / "images" / f"{idx}.png")
        Image.fromarray(msk).save(dst / "masks" / f"{idx}.png")
        lab = r["label"] - 1
        rows.append(dict(idx=idx, label=lab, label_name=LABEL_NAMES[lab], pid=r["pid"],
                         h=img.shape[0], w=img.shape[1],
                         img_path=f"images/{idx}.png", mask_path=f"masks/{idx}.png"))
        if i == 0:
            print(f"first file: dtype={r['image'].dtype} shape={r['image'].shape} "
                  f"min={r['image'].min()} max={r['image'].max()} label={r['label']} pid={r['pid']}")
        if (i + 1) % 500 == 0:
            print(f"  {i + 1}/{len(files)}")

    rows.sort(key=lambda x: x["idx"])
    with open(dst / "meta.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    return rows


def summarize(rows):
    print("\n--- summary ---")
    print("slices:", len(rows))
    print("slices per class:", dict(Counter(r["label_name"] for r in rows)))
    pids = defaultdict(list)
    for r in rows:
        pids[r["pid"]].append(r)
    print("patients:", len(pids))
    print("patients per class:",
          dict(Counter(next(iter({x['label_name'] for x in v})) for v in pids.values())))
    n = [len(v) for v in pids.values()]
    print(f"slices per patient: min={min(n)} median={int(np.median(n))} max={max(n)}")
    multi = [k for k, v in pids.items() if len({x["label"] for x in v}) > 1]
    print("patients with more than one label (should be 0):", len(multi))
    print("image sizes:", dict(Counter((r["h"], r["w"]) for r in rows)))


def read_cvind(path):
    """cvind.mat may be v7.3 (HDF5) or older; return a flat int array."""
    try:
        import h5py
        with h5py.File(path, "r") as f:
            key = [k for k in f.keys() if not k.startswith("#")][0]
            return np.array(f[key]).flatten().astype(int)
    except OSError:
        from scipy.io import loadmat
        m = loadmat(str(path))
        key = [k for k in m if not k.startswith("__")][0]
        return np.asarray(m[key]).flatten().astype(int)


def check_authors_folds(src, rows):
    """cvind.mat = the dataset authors' 5-fold split. Does it keep patients together?"""
    p = src / "cvind.mat"
    if not p.exists():
        return
    try:
        folds = read_cvind(p)
        if len(folds) != len(rows):
            print(f"\ncvind.mat length {len(folds)} != {len(rows)} slices; skipped")
            return
        by_idx = {r["idx"]: r for r in rows}
        pid_folds = defaultdict(set)
        for i, f in enumerate(folds, start=1):          # assumes cvind order == file index order
            pid_folds[by_idx[i]["pid"]].add(int(f))
        split = sum(len(s) > 1 for s in pid_folds.values())
        print(f"\ncvind.mat: folds={sorted(set(folds.tolist()))}; "
              f"{split}/{len(pid_folds)} patients appear in more than one fold")
        # how many slices of each fold have a same-patient slice in another fold's train part
        leaked = 0
        for r in rows:
            if len(pid_folds[r["pid"]]) > 1:
                leaked += 1
        print(f"slices belonging to patients that span folds: {leaked}/{len(rows)}")
    except Exception as e:                              # noqa: BLE001
        print("\ncould not read cvind.mat:", e)


def load_rows(dst):
    with open(dst / "meta.csv", newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        r["idx"], r["label"] = int(r["idx"]), int(r["label"])
    return rows


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default=str(SRC))
    ap.add_argument("--dst", default=str(DST))
    ap.add_argument("--check-only", action="store_true",
                    help="skip conversion; only re-run the cvind check using the existing meta.csv")
    a = ap.parse_args()
    src, dst = Path(a.src), Path(a.dst)
    if a.check_only:
        check_authors_folds(src, load_rows(dst))
    else:
        rows = convert(src, dst)
        summarize(rows)
        check_authors_folds(src, rows)
        print("\ndone ->", dst)
