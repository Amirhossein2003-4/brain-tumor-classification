"""
band_presets.py - the list of input conditions used by screen_bands.py and show_bands.py.

Distances are in pixels of the ORIGINAL 512 x 512 grid, measured from the tumor BOUNDARY.
Rough physical size (README: 0.49 mm per pixel at 512; this is an assumption, 15 slices are 256x256):
    10 px ~ 5 mm | 25 px ~ 12 mm | 50 px ~ 25 mm | 100 px ~ 49 mm | 200 px ~ 98 mm
At the 160-pixel cache one cache pixel is 3.2 original pixels, so bands thinner than ~10 px are only 1-3 pixels wide.

"""


def _band(op, lo, hi, tumor=False, shuffle=False, unit="px512"):
    return {"in": lo, "out": hi, "unit": unit, "tumor": tumor, "op": op, "shuffle": shuffle, "seed": 0}


def _cond(name, mode, band=None, fill="blur"):
    return dict(name=name, mode=mode, band=band, fill=fill, margin=0)


def keep(lo, hi, tumor=False, shuffle=False, unit="px512"):
    t = "tumor+" if tumor else "ring "
    s = " shuf" if shuffle else ""
    return _cond(f"keep {t}{lo}-{hi}{'rel' if unit == 'rel' else ''}{s}", "band",
                 _band("keep", lo, hi, tumor, shuffle, unit), fill="zero")


def remove(lo, hi, tumor=False, shuffle=False, unit="px512"):
    t = "tumor+ring " if tumor else "ring "
    s = " shuf" if shuffle else ""
    return _cond(f"remove {t}{lo}-{hi}{'rel' if unit == 'rel' else ''}{s}", "band",
                 _band("remove", lo, hi, tumor, shuffle, unit), fill="mean")


BASE = [_cond("full", "full"), _cond("tumor_only", "tumor_only"), _cond("context_only", "context_only"),
        _cond("mask_only", "mask_only")]

SMALL = BASE + [
    keep(0, 25, tumor=True), keep(0, 100, tumor=True),
    keep(0, 25), keep(25, 100), keep(0, 25, shuffle=True),
    remove(0, 25),
]

FULL = BASE + [
    # sufficiency, tumor excluded: how far from the tumor does a ring alone still carry information?
    keep(0, 10), keep(10, 25), keep(25, 50), keep(50, 100), keep(100, 200),
    # structure control: same geometry, same histogram, no structure
    keep(0, 10, shuffle=True), keep(10, 25, shuffle=True), keep(25, 50, shuffle=True), keep(50, 100, shuffle=True),
    # sufficiency, tumor included: does adding a ring to the tumor help?
    keep(0, 10, tumor=True), keep(0, 25, tumor=True), keep(0, 50, tumor=True), keep(0, 100, tumor=True),
    # necessity, tumor visible: does removing a ring (and keeping the rest) hurt?
    remove(0, 10), remove(0, 25), remove(0, 50), remove(0, 100),
    # necessity structure control: the ring is shuffled instead of removed
    remove(0, 25, shuffle=True), remove(25, 50, shuffle=True),
]

PRESETS = {"small": SMALL, "full": FULL}
