"""
screen_bands.py - FAST SCREENING of many input conditions (minutes instead of hours).

Every condition (full, tumor_only, context_only, distance bands, shuffled bands, ...) is embedded ONCE with the
frozen pretrained MobileNetV3-small (no fine-tuning); a logistic regression is then trained on the embeddings with
the same patient-level folds as train.py. This tells you which conditions are worth a real fine-tuning run.

    python screen_bands.py preset=small          # ~10 conditions
    python screen_bands.py preset=full           # ~30 conditions (longer)
    python screen_bands.py preset=small size=224 boot=1000



How to read it: frozen ImageNet features + a linear classifier measure how much class information is LINEARLY
decodable from the pixels shown. It is a screening tool: differences between conditions must be confirmed by
fine-tuning (train.py input_mode=band ...) before you trust them. Frozen features can rank conditions differently
from a fine-tuned network.
"""
import csv
import sys
import time
from pathlib import Path

import numpy as np
import torch
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from band_presets import PRESETS  # noqa: E402
from data import BrainTumorDataset, build_cache, make_input  # noqa: E402
from splits import ROOT, load_meta, make_folds  # noqa: E402
from summarize_runs import fast_metrics  # noqa: E402

OPT = dict(preset="small", size=160, root=str(ROOT), mode="patient", seed=0, boot=1000, C=0.1, pretrained=True,
           weights=r"C:\Users\amir\DL\models\mobilenet_v3_small\mobilenet_v3_small.pth")
for a in sys.argv[1:]:
    k, v = a.split("=", 1)
    if k not in OPT:
        raise SystemExit(f"unknown option {k}; valid: {sorted(OPT)}")
    OPT[k] = {"size": int, "seed": int, "boot": int, "C": float,
              "pretrained": lambda x: x.lower() in ("1", "true", "yes")}.get(k, str)(v)

root = Path(OPT["root"])
meta = load_meta(root)
images, masks = build_cache(root, size=OPT["size"])
conds = PRESETS[OPT["preset"]]
cache_dir = root / "screen_cache"
cache_dir.mkdir(exist_ok=True)

net = None


def get_net():
    global net
    if net is None:
        from torchvision.models import mobilenet_v3_small
        from train import load_pretrained_mobilenet
        net = (load_pretrained_mobilenet(dict(pretrained_path=OPT["weights"])) if OPT["pretrained"]
               else mobilenet_v3_small(weights=None))
        net.eval()
    return net


def embed(inp):
    dl = DataLoader(BrainTumorDataset(inp, meta["label"], np.arange(len(inp))), batch_size=64)
    out = []
    with torch.no_grad():
        for x, _ in dl:
            out.append(get_net().features(x).mean(dim=(2, 3)).numpy())
    return np.concatenate(out)


def tag(c):
    t = c["name"].replace(" ", "_").replace("+", "p")
    return f"emb_{t}_{OPT['size']}{'' if OPT['pretrained'] else '_rand'}.npy"


y, pid = meta["label"], meta["pid"]
folds = make_folds(meta, OPT["mode"], 5, OPT["seed"])
P_all = {}
t0 = time.time()
for ci, c in enumerate(conds):
    f = cache_dir / tag(c)
    if f.exists():
        E = np.load(f)
    else:
        inp = make_input(images, masks, c["mode"], c["fill"], c["margin"], band=c["band"])
        E = embed(inp)
        np.save(f, E)
    P = np.zeros((len(y), 3))
    for tr, te in folds:
        clf = make_pipeline(StandardScaler(), LogisticRegression(C=OPT["C"], class_weight="balanced", max_iter=3000))
        clf.fit(E[tr], y[tr])
        P[te] = clf.predict_proba(E[te])
    P_all[c["name"]] = P
    print(f"[{ci + 1}/{len(conds)}] {c['name']:<28} done ({time.time() - t0:.0f}s)")

# ---------------- patient-level bootstrap (same resampled patients for every condition) ----------------
upid = np.unique(pid)
groups = {u: np.where(pid == u)[0] for u in upid}
pcls = {u: int(y[groups[u][0]]) for u in upid}
by_class = [np.array([u for u in upid if pcls[u] == c]) for c in range(3)]
rng = np.random.default_rng(0)
preds = {n: P.argmax(1) for n, P in P_all.items()}
draws = {n: [] for n in P_all}
for b in range(OPT["boot"]):
    sel = np.concatenate([rng.choice(bc, size=len(bc), replace=True) for bc in by_class if len(bc)])
    idx = np.concatenate([groups[u] for u in sel])
    for n in P_all:
        draws[n].append(fast_metrics(y, P_all[n], preds[n], idx))

rows = []
print(f"\n=== screening ({OPT['mode']} split, frozen features + logistic regression, "
      f"{len(upid)} patients, {OPT['boot']} patient-level bootstrap draws) ===")
print(f"{'condition':<28} {'macro AUC [95% CI]':<24} {'men':>6} {'gli':>6} {'pit':>6} {'bal.acc':>8}")
allidx = np.arange(len(y))
for c in conds:
    n = c["name"]
    pt = fast_metrics(y, P_all[n], preds[n], allidx)
    lo, hi = np.percentile([d["auc_macro"] for d in draws[n]], [2.5, 97.5])
    print(f"{n:<28} {pt['auc_macro']:.3f} [{lo:.3f},{hi:.3f}]     {pt['auc_men']:.3f}  {pt['auc_gli']:.3f}  {pt['auc_pit']:.3f}  {pt['bal_acc']:.3f}")
    rows.append(dict(condition=n, auc_macro=pt["auc_macro"], auc_lo=lo, auc_hi=hi, auc_men=pt["auc_men"],
                     auc_gli=pt["auc_gli"], auc_pit=pt["auc_pit"], bal_acc=pt["bal_acc"]))
out_csv = root / f"screen_bands_{OPT['preset']}.csv"
with open(out_csv, "w", newline="", encoding="utf-8") as f:
    wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    wr.writeheader()
    wr.writerows(rows)

# ---------------- paired contrasts (same resampled patients -> paired differences) ----------------
def paired_pairs(names):
    pairs = []
    for n in names:
        if n.endswith(" shuf") and n[:-5] in names:
            pairs.append((n[:-5], n, "structure: real - shuffled twin"))
        if n.startswith("keep tumor+"):
            pairs.append((n, "tumor_only", "adding a ring to the tumor"))
        if n.startswith("remove ") and not n.endswith(" shuf") and "full" in names:
            pairs.append((n, "full", "removing the ring"))
        if n.startswith("keep ring") and not n.endswith(" shuf") and "mask_only" in names:
            pairs.append((n, "mask_only", "ring vs silhouette only"))
    for a, b, lab in (("context_only", "tumor_only", "context vs tumor"), ("tumor_only", "mask_only", "tumor vs silhouette"),
                      ("full", "context_only", "full vs context"), ("full", "tumor_only", "full vs tumor")):
        if a in names and b in names:
            pairs.append((a, b, lab))
    return [p_ for p_ in pairs if p_[0] in names and p_[1] in names]


crow = []
print(f"\n=== paired contrasts, AUC difference A - B with 95% patient-level CI (* = excludes 0; many comparisons: hints, not conclusions) ===")
print(f"{'A  -  B':<52} {'macro':>22} {'men':>22} {'gli':>22} {'pit':>22}")
for a, b, lab in paired_pairs(list(P_all)):
    cells = []
    for k in ("auc_macro", "auc_men", "auc_gli", "auc_pit"):
        d = np.array([x[k] for x in draws[a]]) - np.array([x[k] for x in draws[b]])
        lo, hi = np.percentile(d[~np.isnan(d)], [2.5, 97.5])
        pt = fast_metrics(y, P_all[a], preds[a], np.arange(len(y)))[k] - fast_metrics(y, P_all[b], preds[b], np.arange(len(y)))[k]
        cells.append(f"{pt:+.3f} [{lo:+.3f},{hi:+.3f}]{'*' if (lo > 0 or hi < 0) else ' '}")
        crow.append(dict(A=a, B=b, meaning=lab, metric=k, diff=pt, lo=lo, hi=hi))
    print(f"{(a + '  -  ' + b):<52} " + " ".join(f"{c:>22}" for c in cells) + f"   [{lab}]")
if crow:
    with open(root / f"screen_bands_contrasts_{OPT['preset']}.csv", "w", newline="", encoding="utf-8") as f:
        wr = csv.DictWriter(f, fieldnames=list(crow[0].keys()))
        wr.writeheader()
        wr.writerows(crow)

fig, ax = plt.subplots(figsize=(9, 0.38 * len(rows) + 1.8))
yy = np.arange(len(rows))[::-1]
v = np.array([r["auc_macro"] for r in rows])
err = np.array([[r["auc_macro"] - r["auc_lo"], r["auc_hi"] - r["auc_macro"]] for r in rows]).T
col = ["tab:gray" if r["condition"] in ("full", "tumor_only", "context_only", "mask_only") else
       ("tab:red" if "shuf" in r["condition"] else "tab:blue") for r in rows]
ax.barh(yy, v, xerr=err, color=col, capsize=2)
ax.axvline(0.5, color="k", lw=0.6, ls=":")
ax.set_yticks(yy)
ax.set_yticklabels([r["condition"] for r in rows], fontsize=8)
ax.set_xlim(0.5, 1.0)
ax.set_xlabel("macro AUC (frozen features + logistic regression), 95% patient-level CI")
ax.set_title(f"screening - {OPT['preset']} ({OPT['mode']} split); gray = reference, red = shuffled control")
ax.grid(alpha=0.3, axis="x")
plt.tight_layout()
out_png = root / f"screen_bands_{OPT['preset']}.png"
plt.savefig(out_png, dpi=130)
print(f"\nsaved {out_csv} and {out_png}")
print("Screening only: confirm the interesting conditions with fine-tuning (train.py input_mode=band ...).")

