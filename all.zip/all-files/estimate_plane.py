"""
estimate_plane.py - the dataset has NO scan-plane label (axial / coronal / sagittal), but the plane can be a
confounder (e.g. pituitary tumors are mostly imaged in the coronal/sagittal plane). This script estimates the plane
without manual labelling of 3064 images:

  1. embeds every slice with the pretrained MobileNetV3-small (global average pooled features, no fine-tuning);
  2. PCA + k-means with k=3;
  3. checks how stable the clustering is (adjusted Rand index between different k-means seeds);
  4. saves a montage with random slices of each cluster, so YOU can look and name the clusters;
  5. prints the class x cluster table and the cluster sizes (the public dataset has roughly 1025 sagittal,
     994 axial and 1045 coronal slices, so a good clustering should give three groups of about a third each).

Step A (cluster + montage):     python estimate_plane.py
Step B (name them, after you looked at plane_clusters.png):
                                python estimate_plane.py names=0:axial,1:coronal,2:sagittal

"""
import csv
import sys
from pathlib import Path

import numpy as np
import torch
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import adjusted_rand_score
from torch.utils.data import DataLoader

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from data import BrainTumorDataset, build_cache  # noqa: E402
from splits import ROOT, load_meta  # noqa: E402

OPT = dict(root=str(ROOT), size=160, k=3, pretrained=True, names="", seed=0,
           weights=r"C:\Users\amir\DL\models\mobilenet_v3_small\mobilenet_v3_small.pth")
for a in sys.argv[1:]:
    key, v = a.split("=", 1)
    if key not in OPT:
        raise SystemExit(f"unknown option {key}; valid: {sorted(OPT)}")
    OPT[key] = {"size": int, "k": int, "seed": int, "pretrained": lambda x: x.lower() in ("1", "true", "yes")}.get(key, str)(v)

root = Path(OPT["root"])
meta = load_meta(root)
images, _ = build_cache(root, size=OPT["size"])
emb_file = root / f"plane_embeddings_{OPT['size']}.npy"

if emb_file.exists():
    E = np.load(emb_file)
    print("loaded", emb_file)
else:
    from torchvision.models import mobilenet_v3_small
    from train import load_pretrained_mobilenet
    net = load_pretrained_mobilenet(dict(pretrained_path=OPT["weights"])) if OPT["pretrained"] else mobilenet_v3_small(weights=None)
    net.eval()
    dl = DataLoader(BrainTumorDataset(images, meta["label"], np.arange(len(images))), batch_size=64)
    feats = []
    with torch.no_grad():
        for x, _ in dl:
            feats.append(net.features(x).mean(dim=(2, 3)).numpy())
            if len(feats) % 10 == 0:
                print(f"  embedded {sum(len(f) for f in feats)}/{len(images)}")
    E = np.concatenate(feats)
    np.save(emb_file, E)
    print("saved", emb_file)

Z = PCA(n_components=min(20, E.shape[1]), random_state=0).fit_transform(E)
runs = [KMeans(OPT["k"], n_init=10, random_state=s).fit(Z) for s in range(5)]
labels = runs[OPT["seed"]].labels_
ari = [adjusted_rand_score(labels, r.labels_) for r in runs if r is not runs[OPT["seed"]]]
print(f"k-means stability (adjusted Rand index vs 4 other seeds): mean {np.mean(ari):.3f} min {np.min(ari):.3f} "
      f"(1.0 = identical; below ~0.8 means the clusters are not well defined)")

names = {}
if OPT["names"]:
    for t in OPT["names"].split(","):
        a, b = t.split(":")
        names[int(a)] = b
plane = np.array([names.get(int(c), "") for c in labels])

print("\ncluster sizes:", np.bincount(labels).tolist(), "(expected roughly a third each if the plane is what separates them)")
print("class x cluster table (rows: meningioma, glioma, pituitary):")
tab = np.array([[int(((meta["label"] == c) & (labels == k)).sum()) for k in range(OPT["k"])] for c in range(3)])
print(tab)
pid_clusters = {}
for p, c in zip(meta["pid"], labels):
    pid_clusters.setdefault(p, set()).add(int(c))
n_single = sum(len(v) == 1 for v in pid_clusters.values())
print(f"patients whose slices all fall in ONE cluster: {n_single}/{len(pid_clusters)}")

rng = np.random.default_rng(0)
cols = 10
fig, ax = plt.subplots(OPT["k"], cols, figsize=(2 * cols, 2.2 * OPT["k"]))
for k in range(OPT["k"]):
    ids = rng.choice(np.where(labels == k)[0], size=min(cols, int((labels == k).sum())), replace=False)
    for j in range(cols):
        ax[k, j].axis("off")
        if j < len(ids):
            ax[k, j].imshow(images[ids[j]].astype(np.float32), cmap="gray", vmin=0, vmax=1)
    ax[k, 0].set_title(f"cluster {k}  (n={int((labels == k).sum())})", fontsize=9, loc="left")
plt.tight_layout()
plt.savefig(root / "plane_clusters.png", dpi=110)
plt.close()

with open(root / "plane_clusters.csv", "w", newline="", encoding="utf-8") as f:
    wr = csv.writer(f)
    wr.writerow(["slice_idx", "pid", "cluster", "plane"])
    for i in range(len(labels)):
        wr.writerow([int(meta["idx"][i]), meta["pid"][i], int(labels[i]), plane[i]])
print("\nsaved plane_clusters.png and plane_clusters.csv in", root)
if not names:
    print("Open plane_clusters.png, decide which cluster is axial / coronal / sagittal, then rerun with "
          "names=0:axial,1:coronal,2:sagittal (use YOUR mapping).")
