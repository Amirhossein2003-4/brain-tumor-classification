"""
data.py - turns the PNGs from prep_data.py into a fast in-memory cache + a map-style Dataset.

No torch import needed: torch's DataLoader accepts any object with __len__/__getitem__
and converts the returned numpy arrays to tensors by itself.

Normalization (decided HERE, not in prep_data.py, so it can be changed/compared later):
    per image: clip to [p_low, p_high] percentiles, scale to [0,1], resize to SIZE x SIZE.
"""
from pathlib import Path

import numpy as np
from PIL import Image
from scipy import ndimage

from splits import ROOT, load_meta

# ----------------------------- CONFIG ---------------------------------------
SIZE = 160                       # try 128 / 160 / 224
P_LOW, P_HIGH = 1.0, 99.5        # percentile window for per-image normalization
IMAGENET_MEAN = np.array([0.485, 0.456, 0.406], dtype=np.float32)[:, None, None]
IMAGENET_STD = np.array([0.229, 0.224, 0.225], dtype=np.float32)[:, None, None]
# -----------------------------------------------------------------------------


def _norm_resize(path, size, p_low, p_high):
    im = np.array(Image.open(path)).astype(np.float32)
    lo, hi = np.percentile(im, [p_low, p_high])
    im = np.clip((im - lo) / (hi - lo + 1e-8), 0.0, 1.0).astype(np.float32)   # must be float32 for PIL mode "F"
    return np.array(Image.fromarray(im).resize((size, size), Image.BILINEAR), dtype=np.float32)


def build_cache(root=ROOT, size=SIZE, p_low=P_LOW, p_high=P_HIGH, force=False):
    """Create (or load) root/cache_{size}.npz with images (N,size,size) float16 + masks (N,size,size) uint8."""
    root = Path(root)
    f = root / f"cache_{size}.npz"
    if f.exists() and not force:
        z = np.load(f)
        return z["images"], z["masks"]
    meta = load_meta(root)
    n = len(meta["idx"])
    images = np.zeros((n, size, size), dtype=np.float16)
    masks = np.zeros((n, size, size), dtype=np.uint8)
    for i in range(n):
        images[i] = _norm_resize(root / meta["img_path"][i], size, p_low, p_high)
        m = Image.open(root / meta["mask_path"][i]).resize((size, size), Image.NEAREST)
        masks[i] = (np.array(m) > 0).astype(np.uint8)
        if (i + 1) % 500 == 0:
            print(f"  cached {i + 1}/{n}")
    np.savez_compressed(f, images=images, masks=masks)
    print("saved", f)
    return images, masks


def _blur_fill(img, m):
    """Fill the pixels where m is True with a smooth estimate from the surrounding (known) pixels.
    Multi-scale normalized convolution: small sigma fills the hole border, larger sigma fills the center."""
    valid = (~m).astype(np.float32)
    out = img.copy()
    got = ~m
    for s in (3, 6, 12, 24, 48):
        num = ndimage.gaussian_filter(img * valid, s)
        den = ndimage.gaussian_filter(valid, s)
        est = num / np.maximum(den, 1e-6)
        sel = m & ~got & (den > 0.1)
        out[sel] = est[sel]
        got = got | sel
    out[m & ~got] = float(img[~m].mean()) if (~m).any() else 0.0
    return out


def _fill_region(img, sup, fill):
    """Replace the pixels where sup is True."""
    if not sup.any():
        return img
    if fill == "zero":
        return np.where(sup, 0.0, img).astype(np.float32)
    if fill == "mean":
        known = img[~sup]
        return np.where(sup, float(known.mean()) if known.size else 0.0, img).astype(np.float32)
    return _blur_fill(img, sup)          # "blur": meant for small holes; use zero/mean to suppress large areas


def make_band_one(img, m, i, band, fill):
    """One slice. img float32 (S,S) in [0,1]; m bool tumor mask (S,S); i = slice row (seeds the shuffle)."""
    S = img.shape[0]
    d = ndimage.distance_transform_edt(~m)               # distance to the tumor boundary; 0 inside the tumor
    if band.get("unit", "px512") == "rel":
        k = float(np.sqrt(max(int(m.sum()), 1) / np.pi))
    else:
        k = S / 512.0                                    # cache pixels per pixel of the original 512 grid
    lo, hi = band["in"] * k, band["out"] * k
    ring = (~m) & (d > lo) & (d <= hi)
    tum = m if band.get("tumor", False) else np.zeros_like(m)
    work = img.astype(np.float32).copy()
    if band.get("shuffle", False) and ring.any():
        ridx = np.flatnonzero(ring)
        rng = np.random.default_rng(int(band.get("seed", 0)) * 100003 + int(i))
        flat = work.reshape(-1)
        flat[ridx] = rng.permutation(flat[ridx])
    if band.get("op", "keep") == "keep":
        sup = ~(ring | tum)
    else:
        sup = (np.zeros_like(ring) if band.get("shuffle", False) else ring) | tum
    return _fill_region(work, sup, fill)


def make_input(images, masks, mode="full", fill="blur", margin=0, band=None):
    """
    Build the model input from the cached images and tumor masks (cache files are NOT modified).
      full          : the image as is
      tumor_only    : only the tumor pixels are kept, everything else = 0 (black)
      context_only  : the tumor pixels are removed (filled), the surrounding anatomy is kept
      mask_only     : the binary tumor silhouette (no texture at all) - a control for shape/location
    margin : dilate the tumor mask by this many pixels (at the cache size) before using it.
             tumor_only + margin = tumor plus a rim of surrounding tissue; context_only + margin
             also removes the rim (edema / boundary).
    fill   : how the removed / suppressed region is filled: "blur" | "mean" | "zero"
    band   : dict for mode "band" (distance bands measured from the tumor BOUNDARY, see make_band_one):
               in, out : inner / outer distance of the ring (ring = pixels outside the tumor with in < d <= out)
               unit    : "px512" (pixels of the original 512 grid; the cache is rescaled automatically) or
                         "rel" (multiples of the tumor's equivalent radius sqrt(area/pi))
               tumor   : True = the tumor interior belongs to the region of interest
               op      : "keep"   -> keep only (tumor +) ring, suppress everything else   (sufficiency)
                         "remove" -> suppress (tumor +) ring, keep everything else        (necessity)
               shuffle : True = pixel values inside the ring are randomly permuted (same histogram and geometry,
                         structure destroyed); in "remove" mode the ring is shuffled instead of suppressed
               seed    : seed of the permutation
    """
    if mode == "full":
        return images
    if mode not in ("tumor_only", "context_only", "mask_only", "band"):
        raise ValueError(f"unknown input_mode '{mode}'")
    if mode == "band" and not band:
        raise ValueError("input_mode 'band' needs the band settings")
    out = np.empty_like(images)
    for i in range(len(images)):
        img = images[i].astype(np.float32)
        m = masks[i] > 0
        if margin > 0 and mode != "band":
            m = ndimage.binary_dilation(m, iterations=int(margin))
        if mode == "band":
            res = make_band_one(img, masks[i] > 0, i, band, fill)
        elif mode == "tumor_only":
            res = np.where(m, img, 0.0)
        elif mode == "mask_only":
            res = m.astype(np.float32)
        else:
            if fill == "zero":
                res = np.where(m, 0.0, img)
            elif fill == "mean":
                res = np.where(m, float(img[~m].mean()) if (~m).any() else 0.0, img)
            else:
                res = _blur_fill(img, m)
        out[i] = res
    return out


class BrainTumorDataset:
    """Map-style dataset. Returns (x[3,S,S] float32, y int). Row indices refer to meta row order."""

    def __init__(self, images, labels, indices, transform=None):
        self.images, self.labels = images, labels
        self.indices = np.asarray(indices)
        self.transform = transform          # optional: callable(2D float32 array in [0,1]) -> 2D array

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, k):
        i = self.indices[k]
        x = self.images[i].astype(np.float32)
        if self.transform is not None:
            x = self.transform(x)
        x = np.repeat(x[None], 3, axis=0)                   # grayscale -> 3 channels
        x = (x - IMAGENET_MEAN) / IMAGENET_STD
        return x.astype(np.float32), int(self.labels[i])


if __name__ == "__main__":
    # usage:  python data.py            -> builds the cache for SIZE
    #         python data.py 160 224    -> builds one cache per size (skips sizes already cached)
    import sys
    sizes = [int(a) for a in sys.argv[1:]] or [SIZE]
    meta = load_meta()
    for s in sizes:
        print(f"== size {s} ==")
        images, masks = build_cache(size=s)
        print("images", images.shape, images.dtype, "| masks", masks.shape,
              "| mean tumor fraction: %.4f" % masks.mean())
        ds = BrainTumorDataset(images, meta["label"], np.arange(len(images)))
        x, y = ds[0]
        print("sample:", x.shape, x.dtype, "label", y, "| x mean/std: %.2f / %.2f" % (x.mean(), x.std()))
